<?php

// FOSUserBundle:ChangePassword:changePassword_content.html.twig
return array (
);
