<?php

// :Szablony:glowna.html.twig
return array (
  '0c961fa' => 
  array (
    0 => 
    array (
      0 => '@AppBundle/Resources/css/style.css*',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/0c961fa.css',
      'name' => '0c961fa',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '9b0345b' => 
  array (
    0 => 
    array (
      0 => '@AppBundle/Resources/css/glowna.css*',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/9b0345b.css',
      'name' => '9b0345b',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
