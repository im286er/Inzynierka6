<?php

// FOSUserBundle:Group:edit.html.twig
return array (
);
