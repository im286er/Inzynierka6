<?php

// FOSUserBundle:Group:list.html.twig
return array (
);
