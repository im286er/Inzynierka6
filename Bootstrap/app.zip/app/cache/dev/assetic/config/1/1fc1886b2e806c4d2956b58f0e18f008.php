<?php

// FOSUserBundle:Resetting:reset_content.html.twig
return array (
  '95e3bdb' => 
  array (
    0 => 
    array (
      0 => '@AppBundle/Resources/css/register2.css*',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/95e3bdb.css',
      'name' => '95e3bdb',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
