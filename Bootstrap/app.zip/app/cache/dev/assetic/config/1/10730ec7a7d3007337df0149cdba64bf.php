<?php

// FOSUserBundle:Profile:edit_content.html.twig
return array (
);
