<?php

// FOSUserBundle:Profile:show_content.html.twig
return array (
);
