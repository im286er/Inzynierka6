<?php

/* :Szablony:oferta.html.twig */
class __TwigTemplate_ba0117cdd20df16c0b506aac4750133797b8ca08dc02b07c9674678e929f331c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":Szablony:oferta.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b749e3be610afc5899dfb9adbf959ce0e269e643906ed17b129487860719c70a = $this->env->getExtension("native_profiler");
        $__internal_b749e3be610afc5899dfb9adbf959ce0e269e643906ed17b129487860719c70a->enter($__internal_b749e3be610afc5899dfb9adbf959ce0e269e643906ed17b129487860719c70a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Szablony:oferta.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b749e3be610afc5899dfb9adbf959ce0e269e643906ed17b129487860719c70a->leave($__internal_b749e3be610afc5899dfb9adbf959ce0e269e643906ed17b129487860719c70a_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_92a39e46337f000372701e146901602faee5d5589f12f5eb959c52ed0019ba78 = $this->env->getExtension("native_profiler");
        $__internal_92a39e46337f000372701e146901602faee5d5589f12f5eb959c52ed0019ba78->enter($__internal_92a39e46337f000372701e146901602faee5d5589f12f5eb959c52ed0019ba78_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        echo "    <div class=\"fos_user_user_show\">
        <div class=\"container-fluid \" id=\"kontener\">
            <div class=\"col-sm-8 col-sm-offset-2\">
                <div class=\"row\">
                    <div class=\"col-sm-7\">
                        <h2 class=\"page-header text-center\">";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "tytul", array()), "html", null, true);
        echo "</h2>
                        <div id=\"main_area\">
                            <!-- Slider -->
                            <div class=\"row\">
                                <div class=\"col-sm-6\">
                                    <div class=\"col-xs-12\" id=\"slider\">
                                        <!-- Top part of the slider -->
                                        <div class=\"row\">
                                            <div class=\"col-sm-12\" id=\"carousel-bounding-box\">
                                                <div class=\"carousel slide\" id=\"myCarousel\">
                                                    <!-- Carousel items -->
                                                    <div class=\"carousel-inner\">
                                                        ";
        // line 21
        if (((isset($context["zdjecia"]) ? $context["zdjecia"] : $this->getContext($context, "zdjecia")) != null)) {
            // line 22
            echo "                                                            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["zdjecia"]) ? $context["zdjecia"] : $this->getContext($context, "zdjecia")));
            foreach ($context['_seq'] as $context["_key"] => $context["zdj"]) {
                // line 23
                echo "
                                                                ";
                // line 24
                if (($context["zdj"] == $this->getAttribute((isset($context["zdjecia"]) ? $context["zdjecia"] : $this->getContext($context, "zdjecia")), 0, array(), "array"))) {
                    // line 25
                    echo "                                                                    <div class=\"active item\" data-slide-number=\"0\">
                                                                ";
                } else {
                    // line 27
                    echo "                                                                    <div class=\"item\" data-slide-number=\"0\">
                                                                ";
                }
                // line 29
                echo "
                                                                 <img src=\"";
                // line 30
                echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl($this->getAttribute($context["zdj"], "imagePath", array())), "html", null, true);
                echo "\" />

                                                                 </div>
                                                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['zdj'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 34
            echo "                                                        ";
        }
        // line 35
        echo "

                                                    </div>
                                                    <!-- Carousel nav -->
                                                    <a class=\"left carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"prev\">
                                                        <span class=\"glyphicon glyphicon-chevron-left\"></span>
                                                    </a>
                                                    <a class=\"right carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"next\">
                                                        <span class=\"glyphicon glyphicon-chevron-right\"></span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"col-sm-6 text-left\">
                                    <p><strong>Dostępne od: </strong>";
        // line 51
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "wolneod", array()), "d-m-Y"), "html", null, true);
        echo "</p>
                                    <p><strong>Miasto: </strong>";
        // line 52
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "miasto", array()), "html", null, true);
        echo "</p>
                                    <p><strong>Dzielnica: </strong>";
        // line 53
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "dzielnica", array()), "html", null, true);
        echo "</p>
                                    <p><strong>Ulica: </strong>";
        // line 54
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "ulica", array()), "html", null, true);
        echo "</p>
                                    <p><strong>Typ stancji: </strong>";
        // line 55
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "kategoria", array()), "html", null, true);
        echo "</p>
                                    <p><strong>Typ budynku: </strong>";
        // line 56
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "typ", array()), "html", null, true);
        echo "</p>
                                    <p><strong>Piętro: </strong>";
        // line 57
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "pietro", array()), "html", null, true);
        echo "</p>
                                    <p><strong>Liczba pokoi: </strong>";
        // line 58
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "liczbapokoi", array()), "html", null, true);
        echo "</p>
                                    <p><strong>Maksymalna liczba osób: </strong>";
        // line 59
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "maksliczbosob", array()), "html", null, true);
        echo "</p>
                                    <p><strong>Metraż: </strong>";
        // line 60
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "metraz", array()), "html", null, true);
        echo "</p>
                                    <p><strong>Ogłoszenie wygasa:</strong></p>
                                </div>
                            </div>
                            <div class=\"row\">
                                    <div class=\"col-sm-6\" id=\"slider-thumbs\">
                                        <!-- Bottom switcher of slider -->
                                        <ul class=\"hide-bullets\">
                                            ";
        // line 68
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["zdjecia"]) ? $context["zdjecia"] : $this->getContext($context, "zdjecia")));
        foreach ($context['_seq'] as $context["_key"] => $context["zdj"]) {
            // line 69
            echo "
                                                <li class=\"col-sm-3\">
                                                    <a class=\"thumbnail\" id=\"carousel-selector-0\">

                                                        <img src=\"";
            // line 73
            echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl($this->getAttribute($context["zdj"], "imagePath", array())), "html", null, true);
            echo "\" />

                                                    </a>
                                                </li>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['zdj'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 78
        echo "



                                         </ul>
                                    </div>
                                <!--/Slider-->
                            </div>
                        </div>
                    </div>
                    <div class=\"col-sm-5\" id=\"naw\" >
                        <ul class=\"nav nav-tabs\">
                            <li class=\"active\"><a data-toggle=\"tab\" href=\"#mapa\">Mapa</a></li>
                            <li><a data-toggle=\"tab\" href=\"#kontakt\">Kontakt</a></li>
                        </ul>

                        <div class=\"tab-content\">
                            <div id=\"mapa\" class=\"tab-pane fade in active\">
                                <div id=\"map\" style=\"height:400px;width:100%;\"></div>
                            </div>
                            <div id=\"kontakt\" class=\"tab-pane fade\">
                                <h3 class=\"page-header\">Dodane przez:<a href=\"";
        // line 99
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("_profil", array("id" => $this->getAttribute($this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "userid", array()), "id", array()))), "html", null, true);
        echo "\" class=\"text-left\"> ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "userid", array()), "html", null, true);
        echo "</a></h3>
                                <div class=\"btn-group-vertical  col-sm-4\">
                                    <button id=\"telefon\" class=\"btn btn-default btn-md\">Numer telefonu</button>
                                    <button id=\"email\" class=\"btn btn-default btn-md\">Adres email</button>
                                </div>
                            </div>
                        </div>
                    </div>
                        <button id=\"obs\" type=\"button\" class=\"btn btn-info col-sm-offset-10\">Dodaj do obserwowanych</button>
                </div>
                <div class=\"row\">
                    <div class=\"col-sm-4\">
                        <div class=\"well\" id=\"studnie\" >
                            <h3>Opłaty</h3>
                            <p><strong>Cena za miesiąc: </strong>";
        // line 113
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "cena", array()), "html", null, true);
        echo "</p>
                            <p><strong>Dodatkowe opłaty na miesiąc:</strong>";
        // line 114
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "dodatkoweoplaty", array()), "html", null, true);
        echo "</p>
                            <p><strong>Kaucja:</strong>";
        // line 115
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "kaucja", array()), "html", null, true);
        echo "</p>
                            <p></p>
                        </div>
                    </div>
                    ";
        // line 119
        if (((isset($context["wyposazenie"]) ? $context["wyposazenie"] : $this->getContext($context, "wyposazenie")) != null)) {
            // line 120
            echo "                    <div class=\"col-sm-4\">
                        <div class=\"well\" id=\"studnie\">
                            <h3>Wyposażenie</h3>
                            ";
            // line 123
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["wyposazenie"]) ? $context["wyposazenie"] : $this->getContext($context, "wyposazenie")));
            foreach ($context['_seq'] as $context["_key"] => $context["wyp"]) {
                // line 124
                echo "                                   <lu class=\"\"> ";
                echo twig_escape_filter($this->env, $context["wyp"], "html", null, true);
                echo ",</lu>
                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['wyp'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 126
            echo "                            ";
        }
        // line 127
        echo "                            ";
        if (((isset($context["preferencje"]) ? $context["preferencje"] : $this->getContext($context, "preferencje")) != null)) {
            // line 128
            echo "                            <h3>Współlokatorzy</h3>
                            ";
            // line 129
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["preferencje"]) ? $context["preferencje"] : $this->getContext($context, "preferencje")));
            foreach ($context['_seq'] as $context["_key"] => $context["pref"]) {
                // line 130
                echo "                            <lu> ";
                echo twig_escape_filter($this->env, $context["pref"], "html", null, true);
                echo ",</lu>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pref'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 131
            echo "</p>
                            ";
        }
        // line 133
        echo "                        </div>
                    </div>
                    <div class=\"col-sm-4\">
                        <div class=\"well\" id=\"studnie\">
                                <h3>Opis</h3>
                                <div id=\"opis2\"><lu> ";
        // line 138
        echo twig_escape_filter($this->env, strip_tags($this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "opis", array())), "html", null, true);
        echo "</lu></div>
                        </div>
                    </div>

                </div>
                    <p class=\"text-right col-sm-offset-8\"><strong>Wyświetleń: </strong>";
        // line 143
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "views", array()), "html", null, true);
        echo "</p>
                    <a href=\"#\"><p class=\"text-right col-sm-offset-8\"><strong>Zgłoś naruszenie zasad</strong></p></a>

            </div>
        </div>
    </div>


    <style>
        #opis2{
            word-wrap: break-word;
        }
        #obs{
            position: relative;
            top:-5px;
            left:5px;
        }
        #studnie{

        }
        #naw{
            poistion: relative;
            top: 40px;
        }
        #kontener{
            position: relative;
            top: 60px;
        }
        .hide-bullets {
            list-style:none;
            margin-left: -40px;
            margin-top:20px;
        }

        .thumbnail {
            padding: 0;
        }

        .carousel-inner>.item>img, .carousel-inner>.item>a>img {
            width: 100%;
        }
        .nav-tabs li a {
            color: #777;
        }
    </style>
    <script>
    \$('#obs').click(function(){
    location.replace(\"";
        // line 190
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("_obserwuj", array("idOferty" => $this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "idOferty", array()))), "html", null, true);
        echo "\");
    });
    </script>
    ";
        // line 194
        echo "    <script>
        \$(document).ready(function(){
            \$('#telefon').popover({title: \"nr telefonu\", content: \"";
        // line 196
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "userid", array()), "telefon", array()), "html", null, true);
        echo "\", trigger: \"hover\", placement: \"right\"});
            \$('#email').popover({title: \"Adres email\", content: \"";
        // line 197
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["oferty"]) ? $context["oferty"] : $this->getContext($context, "oferty")), "userid", array()), "email", array()), "html", null, true);
        echo "\", trigger: \"hover\", placement: \"right\"});
        });
    </script>

    ";
        // line 202
        echo "    <script>
        jQuery(document).ready(function(\$) {

            \$('#myCarousel').carousel({
                interval: 5000
            });

            //Handles the carousel thumbnails
            \$('[id^=carousel-selector-]').click(function () {
                var id_selector = \$(this).attr(\"id\");
                try {
                    var id = /-(\\d+)\$/.exec(id_selector)[1];
                    console.log(id_selector, id);
                    jQuery('#myCarousel').carousel(parseInt(id));
                } catch (e) {
                    console.log('Regex failed!', e);
                }
            });
            // When the carousel slides, auto update the text
            \$('#myCarousel').on('slid.bs.carousel', function (e) {
                var id = \$('.item.active').data('slide-number');
                \$('#carousel-text').html(\$('#slide-content-'+id).html());
            });
        });
    </script>

    ";
        // line 229
        echo "    <script src=\"http://maps.googleapis.com/maps/api/js\"></script>
    <script>
        function initialize() {
            var mapCanvas = document.getElementById('map');
            var mapOptions = {
                center: new google.maps.LatLng(51.2379753, 22.5754416),
                zoom: 11,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            }
            var map = new google.maps.Map(mapCanvas, mapOptions)
        }
        google.maps.event.addDomListener(window, 'load', initialize);
    </script>

";
        
        $__internal_92a39e46337f000372701e146901602faee5d5589f12f5eb959c52ed0019ba78->leave($__internal_92a39e46337f000372701e146901602faee5d5589f12f5eb959c52ed0019ba78_prof);

    }

    public function getTemplateName()
    {
        return ":Szablony:oferta.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  401 => 229,  373 => 202,  366 => 197,  362 => 196,  358 => 194,  352 => 190,  302 => 143,  294 => 138,  287 => 133,  283 => 131,  274 => 130,  270 => 129,  267 => 128,  264 => 127,  261 => 126,  252 => 124,  248 => 123,  243 => 120,  241 => 119,  234 => 115,  230 => 114,  226 => 113,  207 => 99,  184 => 78,  173 => 73,  167 => 69,  163 => 68,  152 => 60,  148 => 59,  144 => 58,  140 => 57,  136 => 56,  132 => 55,  128 => 54,  124 => 53,  120 => 52,  116 => 51,  98 => 35,  95 => 34,  85 => 30,  82 => 29,  78 => 27,  74 => 25,  72 => 24,  69 => 23,  64 => 22,  62 => 21,  47 => 9,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block fos_user_content %}*/
/*     <div class="fos_user_user_show">*/
/*         <div class="container-fluid " id="kontener">*/
/*             <div class="col-sm-8 col-sm-offset-2">*/
/*                 <div class="row">*/
/*                     <div class="col-sm-7">*/
/*                         <h2 class="page-header text-center">{{ oferty.tytul }}</h2>*/
/*                         <div id="main_area">*/
/*                             <!-- Slider -->*/
/*                             <div class="row">*/
/*                                 <div class="col-sm-6">*/
/*                                     <div class="col-xs-12" id="slider">*/
/*                                         <!-- Top part of the slider -->*/
/*                                         <div class="row">*/
/*                                             <div class="col-sm-12" id="carousel-bounding-box">*/
/*                                                 <div class="carousel slide" id="myCarousel">*/
/*                                                     <!-- Carousel items -->*/
/*                                                     <div class="carousel-inner">*/
/*                                                         {% if zdjecia!=null %}*/
/*                                                             {% for zdj in zdjecia %}*/
/* */
/*                                                                 {% if zdj==zdjecia[0] %}*/
/*                                                                     <div class="active item" data-slide-number="0">*/
/*                                                                 {% else %}*/
/*                                                                     <div class="item" data-slide-number="0">*/
/*                                                                 {% endif %}*/
/* */
/*                                                                  <img src="{{ asset(zdj.imagePath) }}" />*/
/* */
/*                                                                  </div>*/
/*                                                             {% endfor %}*/
/*                                                         {% endif %}*/
/* */
/* */
/*                                                     </div>*/
/*                                                     <!-- Carousel nav -->*/
/*                                                     <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">*/
/*                                                         <span class="glyphicon glyphicon-chevron-left"></span>*/
/*                                                     </a>*/
/*                                                     <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">*/
/*                                                         <span class="glyphicon glyphicon-chevron-right"></span>*/
/*                                                     </a>*/
/*                                                 </div>*/
/*                                             </div>*/
/*                                         </div>*/
/*                                     </div>*/
/*                                 </div>*/
/*                                 <div class="col-sm-6 text-left">*/
/*                                     <p><strong>Dostępne od: </strong>{{ oferty.wolneod|date('d-m-Y') }}</p>*/
/*                                     <p><strong>Miasto: </strong>{{ oferty.miasto }}</p>*/
/*                                     <p><strong>Dzielnica: </strong>{{  oferty.dzielnica }}</p>*/
/*                                     <p><strong>Ulica: </strong>{{  oferty.ulica }}</p>*/
/*                                     <p><strong>Typ stancji: </strong>{{  oferty.kategoria }}</p>*/
/*                                     <p><strong>Typ budynku: </strong>{{  oferty.typ }}</p>*/
/*                                     <p><strong>Piętro: </strong>{{  oferty.pietro }}</p>*/
/*                                     <p><strong>Liczba pokoi: </strong>{{ oferty.liczbapokoi }}</p>*/
/*                                     <p><strong>Maksymalna liczba osób: </strong>{{ oferty.maksliczbosob }}</p>*/
/*                                     <p><strong>Metraż: </strong>{{ oferty.metraz }}</p>*/
/*                                     <p><strong>Ogłoszenie wygasa:</strong></p>*/
/*                                 </div>*/
/*                             </div>*/
/*                             <div class="row">*/
/*                                     <div class="col-sm-6" id="slider-thumbs">*/
/*                                         <!-- Bottom switcher of slider -->*/
/*                                         <ul class="hide-bullets">*/
/*                                             {% for zdj in zdjecia %}*/
/* */
/*                                                 <li class="col-sm-3">*/
/*                                                     <a class="thumbnail" id="carousel-selector-0">*/
/* */
/*                                                         <img src="{{  asset(zdj.imagePath) }}" />*/
/* */
/*                                                     </a>*/
/*                                                 </li>*/
/*                                             {% endfor %}*/
/* */
/* */
/* */
/* */
/*                                          </ul>*/
/*                                     </div>*/
/*                                 <!--/Slider-->*/
/*                             </div>*/
/*                         </div>*/
/*                     </div>*/
/*                     <div class="col-sm-5" id="naw" >*/
/*                         <ul class="nav nav-tabs">*/
/*                             <li class="active"><a data-toggle="tab" href="#mapa">Mapa</a></li>*/
/*                             <li><a data-toggle="tab" href="#kontakt">Kontakt</a></li>*/
/*                         </ul>*/
/* */
/*                         <div class="tab-content">*/
/*                             <div id="mapa" class="tab-pane fade in active">*/
/*                                 <div id="map" style="height:400px;width:100%;"></div>*/
/*                             </div>*/
/*                             <div id="kontakt" class="tab-pane fade">*/
/*                                 <h3 class="page-header">Dodane przez:<a href="{{ path('_profil', {'id': oferty.userid.id}) }}" class="text-left"> {{ oferty.userid }}</a></h3>*/
/*                                 <div class="btn-group-vertical  col-sm-4">*/
/*                                     <button id="telefon" class="btn btn-default btn-md">Numer telefonu</button>*/
/*                                     <button id="email" class="btn btn-default btn-md">Adres email</button>*/
/*                                 </div>*/
/*                             </div>*/
/*                         </div>*/
/*                     </div>*/
/*                         <button id="obs" type="button" class="btn btn-info col-sm-offset-10">Dodaj do obserwowanych</button>*/
/*                 </div>*/
/*                 <div class="row">*/
/*                     <div class="col-sm-4">*/
/*                         <div class="well" id="studnie" >*/
/*                             <h3>Opłaty</h3>*/
/*                             <p><strong>Cena za miesiąc: </strong>{{ oferty.cena }}</p>*/
/*                             <p><strong>Dodatkowe opłaty na miesiąc:</strong>{{ oferty.dodatkoweoplaty }}</p>*/
/*                             <p><strong>Kaucja:</strong>{{ oferty.kaucja }}</p>*/
/*                             <p></p>*/
/*                         </div>*/
/*                     </div>*/
/*                     {% if wyposazenie!=null %}*/
/*                     <div class="col-sm-4">*/
/*                         <div class="well" id="studnie">*/
/*                             <h3>Wyposażenie</h3>*/
/*                             {% for wyp in wyposazenie %}*/
/*                                    <lu class=""> {{ wyp }},</lu>*/
/*                                 {% endfor %}*/
/*                             {% endif %}*/
/*                             {% if preferencje!=null %}*/
/*                             <h3>Współlokatorzy</h3>*/
/*                             {% for pref in preferencje %}*/
/*                             <lu> {{ pref }},</lu>*/
/*                             {% endfor %}</p>*/
/*                             {% endif %}*/
/*                         </div>*/
/*                     </div>*/
/*                     <div class="col-sm-4">*/
/*                         <div class="well" id="studnie">*/
/*                                 <h3>Opis</h3>*/
/*                                 <div id="opis2"><lu> {{ oferty.opis|striptags }}</lu></div>*/
/*                         </div>*/
/*                     </div>*/
/* */
/*                 </div>*/
/*                     <p class="text-right col-sm-offset-8"><strong>Wyświetleń: </strong>{{  oferty.views }}</p>*/
/*                     <a href="#"><p class="text-right col-sm-offset-8"><strong>Zgłoś naruszenie zasad</strong></p></a>*/
/* */
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* */
/* */
/*     <style>*/
/*         #opis2{*/
/*             word-wrap: break-word;*/
/*         }*/
/*         #obs{*/
/*             position: relative;*/
/*             top:-5px;*/
/*             left:5px;*/
/*         }*/
/*         #studnie{*/
/* */
/*         }*/
/*         #naw{*/
/*             poistion: relative;*/
/*             top: 40px;*/
/*         }*/
/*         #kontener{*/
/*             position: relative;*/
/*             top: 60px;*/
/*         }*/
/*         .hide-bullets {*/
/*             list-style:none;*/
/*             margin-left: -40px;*/
/*             margin-top:20px;*/
/*         }*/
/* */
/*         .thumbnail {*/
/*             padding: 0;*/
/*         }*/
/* */
/*         .carousel-inner>.item>img, .carousel-inner>.item>a>img {*/
/*             width: 100%;*/
/*         }*/
/*         .nav-tabs li a {*/
/*             color: #777;*/
/*         }*/
/*     </style>*/
/*     <script>*/
/*     $('#obs').click(function(){*/
/*     location.replace("{{ path('_obserwuj', { 'idOferty': oferty.idOferty}) }}");*/
/*     });*/
/*     </script>*/
/*     {# Skrypt do kontaktu #}*/
/*     <script>*/
/*         $(document).ready(function(){*/
/*             $('#telefon').popover({title: "nr telefonu", content: "{{ oferty.userid.telefon }}", trigger: "hover", placement: "right"});*/
/*             $('#email').popover({title: "Adres email", content: "{{ oferty.userid.email }}", trigger: "hover", placement: "right"});*/
/*         });*/
/*     </script>*/
/* */
/*     {# Skrypt do galerii #}*/
/*     <script>*/
/*         jQuery(document).ready(function($) {*/
/* */
/*             $('#myCarousel').carousel({*/
/*                 interval: 5000*/
/*             });*/
/* */
/*             //Handles the carousel thumbnails*/
/*             $('[id^=carousel-selector-]').click(function () {*/
/*                 var id_selector = $(this).attr("id");*/
/*                 try {*/
/*                     var id = /-(\d+)$/.exec(id_selector)[1];*/
/*                     console.log(id_selector, id);*/
/*                     jQuery('#myCarousel').carousel(parseInt(id));*/
/*                 } catch (e) {*/
/*                     console.log('Regex failed!', e);*/
/*                 }*/
/*             });*/
/*             // When the carousel slides, auto update the text*/
/*             $('#myCarousel').on('slid.bs.carousel', function (e) {*/
/*                 var id = $('.item.active').data('slide-number');*/
/*                 $('#carousel-text').html($('#slide-content-'+id).html());*/
/*             });*/
/*         });*/
/*     </script>*/
/* */
/*     {# Skrypt do mapki #}*/
/*     <script src="http://maps.googleapis.com/maps/api/js"></script>*/
/*     <script>*/
/*         function initialize() {*/
/*             var mapCanvas = document.getElementById('map');*/
/*             var mapOptions = {*/
/*                 center: new google.maps.LatLng(51.2379753, 22.5754416),*/
/*                 zoom: 11,*/
/*                 mapTypeId: google.maps.MapTypeId.ROADMAP*/
/*             }*/
/*             var map = new google.maps.Map(mapCanvas, mapOptions)*/
/*         }*/
/*         google.maps.event.addDomListener(window, 'load', initialize);*/
/*     </script>*/
/* */
/* {% endblock fos_user_content %}*/
