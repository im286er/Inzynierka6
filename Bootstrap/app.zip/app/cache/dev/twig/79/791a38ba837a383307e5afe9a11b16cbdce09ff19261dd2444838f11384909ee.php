<?php

/* :Szablony:wystawioneogloszenia.html.twig */
class __TwigTemplate_61777cc9f8e524b0ab5c13e60ca5bb4060c133ffac371e7b21a9b355c1f7ecc5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":Szablony:wystawioneogloszenia.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8ce45290ae6ddb96dc85fed7c47e7c01129c338ea30f7d0fa65c8078b352cb1d = $this->env->getExtension("native_profiler");
        $__internal_8ce45290ae6ddb96dc85fed7c47e7c01129c338ea30f7d0fa65c8078b352cb1d->enter($__internal_8ce45290ae6ddb96dc85fed7c47e7c01129c338ea30f7d0fa65c8078b352cb1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Szablony:wystawioneogloszenia.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8ce45290ae6ddb96dc85fed7c47e7c01129c338ea30f7d0fa65c8078b352cb1d->leave($__internal_8ce45290ae6ddb96dc85fed7c47e7c01129c338ea30f7d0fa65c8078b352cb1d_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_8355b3d0f0878e437326bbc22087e547633286056bdabc381955976e9e6386c1 = $this->env->getExtension("native_profiler");
        $__internal_8355b3d0f0878e437326bbc22087e547633286056bdabc381955976e9e6386c1->enter($__internal_8355b3d0f0878e437326bbc22087e547633286056bdabc381955976e9e6386c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        echo "    <style>
        #kontener{
            position: relative;
            top: 60px;
        }
    </style>

    <div class=\"container\" id=\"kontener\">
        <div class=\"col-sm-12\">
        <h1 class=\"page-header text-center\">Wystawione ogłoszenia</h1>

            <table class=\"table\">
                    <tr>
                        ";
        // line 18
        echo "                        <th";
        if ($this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "isSorted", array(0 => "a.tytul"), "method")) {
            echo " class=\"sorted\"";
        }
        echo ">
                        Tytuł</th>
                        <th>";
        // line 20
        echo $this->env->getExtension('knp_pagination')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Kategoria", "a.kategoria");
        echo "</th>
                        <th>";
        // line 21
        echo $this->env->getExtension('knp_pagination')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "Cena ^", "a.cena", array("direction" => "asc"));
        echo $this->env->getExtension('knp_pagination')->sortable($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "v", "a.cena", array("direction" => "desc"));
        echo "</th>
                    </tr>

                    ";
        // line 25
        echo "                    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["oferta"]) {
            // line 26
            echo "                        <tr ";
            if (($this->getAttribute($context["loop"], "index", array()) % 2 == 1)) {
                echo "class=\"color\"";
            }
            echo ">
                            <td><a href=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("_oferta", array("idOferty" => $this->getAttribute($context["oferta"], "idOferty", array()))), "html", null, true);
            echo "\"> ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["oferta"], "tytul", array()), "html", null, true);
            echo "</a></td>
                            <td>";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["oferta"], "kategoria", array()), "html", null, true);
            echo "</td>
                            <td>";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["oferta"], "cena", array()), "html", null, true);
            echo "zł/miesiąc</td>
                            <td>
                                <div class=\"dropdown\">
                                    <button class=\"btn btn-primary dropdown-toggle\" type=\"button\" data-toggle=\"dropdown\">Opcje <span class=\"caret\"></span></button>
                                    <ul class=\"dropdown-menu\">
                                        <li><a href=\"#\"><span class=\"glyphicon glyphicon-wrench\"></span> Zmień</a></li>
                                        <li class=\"divider\"></li>
                                        <li><a data-toggle=\"modal\" id=\"confirm\" data-id=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($context["oferta"], "idOferty", array()), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-trash\"></span> Usuń</a></li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['oferta'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 42
        echo "            </table>
                ";
        // line 44
        echo "
                    ";
        // line 45
        echo $this->env->getExtension('knp_pagination')->render($this->env, (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        echo "

                <div class=\"row col-sm-offset-10\"><a href=\"";
        // line 47
        echo $this->env->getExtension('routing')->getPath("fos_user_profile_show");
        echo "\" class=\"text-center new-account\"><h4>Powrót do profilu</h4></a></div>
        </div>
        </div>


        <div class=\"modal fade\" id=\"myModal\" role=\"dialog\">
            <div class=\"modal-dialog\">
                <!-- Modal content-->
                <div class=\"modal-content\">
                    <div class=\"modal-header\" >
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\"></button>
                        <h4 class=\"text-center\">Potwierdzenie akcji</h4>
                    </div>
                    <div class=\"modal-body\">
                      <h5 class=\"text-center\">Czy na pewno chcesz usunąć tę ofertę?</h5>
                        <button type=\"button\" class=\"btn btn-primary btn-default pull-right\" data-dismiss=\"modal\">
                         <a  class=\"usun\">Anuluj</a></button>
                        <button type=\"button\" id=\"openBtn\" class=\"btn btn-danger btn-default pull-left\" data-dismiss=\"modal\"><span class=\"glyphicon glyphicon-remove\"></span>
                            <a  id=\"delete\"  class=\"usun\">Usuń</a></button>
                    </div>
                </div>

            </div>
        </div>

    </div>



    <script>
    var route;
    var idoferty;
        \$(\"tr #confirm\").click(function(){
         idoferty = \$(this).data('id');
    a = document.getElementById('delete');
    route = \"";
        // line 82
        echo $this->env->getExtension('routing')->getPath("_usun", array("idOferty" => "PLACEHOLDER"));
        echo "\";

     a.setAttribute(\"href\", route.replace(\"PLACEHOLDER\", idoferty) );
  \$(\"#myModal\").modal('show');

});
\$('#openBtn').click(function(){
  location.replace(route.replace(\"PLACEHOLDER\", idoferty));
});

    </script>
    <style>
        .usun{
            color: white;
        }
        .modal-dialog{
            position: absolute;
            left: 35%;
            margin-left: 0px;
            height: 500px;
            top: 50%;
            margin-top: -250px;
        }
        .modal-body{
            padding:10px 50px;
            padding-bottom: 50px;
        }
    </style>
";
        
        $__internal_8355b3d0f0878e437326bbc22087e547633286056bdabc381955976e9e6386c1->leave($__internal_8355b3d0f0878e437326bbc22087e547633286056bdabc381955976e9e6386c1_prof);

    }

    public function getTemplateName()
    {
        return ":Szablony:wystawioneogloszenia.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  188 => 82,  150 => 47,  145 => 45,  142 => 44,  139 => 42,  119 => 36,  109 => 29,  105 => 28,  99 => 27,  92 => 26,  74 => 25,  67 => 21,  63 => 20,  55 => 18,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block fos_user_content %}*/
/*     <style>*/
/*         #kontener{*/
/*             position: relative;*/
/*             top: 60px;*/
/*         }*/
/*     </style>*/
/* */
/*     <div class="container" id="kontener">*/
/*         <div class="col-sm-12">*/
/*         <h1 class="page-header text-center">Wystawione ogłoszenia</h1>*/
/* */
/*             <table class="table">*/
/*                     <tr>*/
/*                         {# sorting of properties based on query components #}*/
/*                         <th{% if pagination.isSorted('a.tytul') %} class="sorted"{% endif %}>*/
/*                         Tytuł</th>*/
/*                         <th>{{ knp_pagination_sortable(pagination, 'Kategoria', 'a.kategoria') }}</th>*/
/*                         <th>{{ knp_pagination_sortable(pagination, 'Cena ^', 'a.cena', {'direction': 'asc'})}}{{ knp_pagination_sortable(pagination, 'v', 'a.cena', {'direction': 'desc'})}}</th>*/
/*                     </tr>*/
/* */
/*                     {# table body #}*/
/*                     {% for oferta in pagination %}*/
/*                         <tr {% if loop.index is odd %}class="color"{% endif %}>*/
/*                             <td><a href="{{ path('_oferta', {'idOferty' : oferta.idOferty}) }}"> {{ oferta.tytul }}</a></td>*/
/*                             <td>{{ oferta.kategoria }}</td>*/
/*                             <td>{{ oferta.cena }}zł/miesiąc</td>*/
/*                             <td>*/
/*                                 <div class="dropdown">*/
/*                                     <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Opcje <span class="caret"></span></button>*/
/*                                     <ul class="dropdown-menu">*/
/*                                         <li><a href="#"><span class="glyphicon glyphicon-wrench"></span> Zmień</a></li>*/
/*                                         <li class="divider"></li>*/
/*                                         <li><a data-toggle="modal" id="confirm" data-id="{{oferta.idOferty}}"><span class="glyphicon glyphicon-trash"></span> Usuń</a></li>*/
/*                                     </ul>*/
/*                                 </div>*/
/*                             </td>*/
/*                         </tr>*/
/*                     {% endfor %}*/
/*             </table>*/
/*                 {# display navigation #}*/
/* */
/*                     {{ knp_pagination_render(pagination) }}*/
/* */
/*                 <div class="row col-sm-offset-10"><a href="{{ path('fos_user_profile_show') }}" class="text-center new-account"><h4>Powrót do profilu</h4></a></div>*/
/*         </div>*/
/*         </div>*/
/* */
/* */
/*         <div class="modal fade" id="myModal" role="dialog">*/
/*             <div class="modal-dialog">*/
/*                 <!-- Modal content-->*/
/*                 <div class="modal-content">*/
/*                     <div class="modal-header" >*/
/*                         <button type="button" class="close" data-dismiss="modal"></button>*/
/*                         <h4 class="text-center">Potwierdzenie akcji</h4>*/
/*                     </div>*/
/*                     <div class="modal-body">*/
/*                       <h5 class="text-center">Czy na pewno chcesz usunąć tę ofertę?</h5>*/
/*                         <button type="button" class="btn btn-primary btn-default pull-right" data-dismiss="modal">*/
/*                          <a  class="usun">Anuluj</a></button>*/
/*                         <button type="button" id="openBtn" class="btn btn-danger btn-default pull-left" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span>*/
/*                             <a  id="delete"  class="usun">Usuń</a></button>*/
/*                     </div>*/
/*                 </div>*/
/* */
/*             </div>*/
/*         </div>*/
/* */
/*     </div>*/
/* */
/* */
/* */
/*     <script>*/
/*     var route;*/
/*     var idoferty;*/
/*         $("tr #confirm").click(function(){*/
/*          idoferty = $(this).data('id');*/
/*     a = document.getElementById('delete');*/
/*     route = "{{ path('_usun', { 'idOferty': "PLACEHOLDER" }) }}";*/
/* */
/*      a.setAttribute("href", route.replace("PLACEHOLDER", idoferty) );*/
/*   $("#myModal").modal('show');*/
/* */
/* });*/
/* $('#openBtn').click(function(){*/
/*   location.replace(route.replace("PLACEHOLDER", idoferty));*/
/* });*/
/* */
/*     </script>*/
/*     <style>*/
/*         .usun{*/
/*             color: white;*/
/*         }*/
/*         .modal-dialog{*/
/*             position: absolute;*/
/*             left: 35%;*/
/*             margin-left: 0px;*/
/*             height: 500px;*/
/*             top: 50%;*/
/*             margin-top: -250px;*/
/*         }*/
/*         .modal-body{*/
/*             padding:10px 50px;*/
/*             padding-bottom: 50px;*/
/*         }*/
/*     </style>*/
/* {% endblock fos_user_content %}*/
