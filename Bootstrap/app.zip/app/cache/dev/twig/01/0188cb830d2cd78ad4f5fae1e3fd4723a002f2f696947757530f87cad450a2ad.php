<?php

/* IvoryGoogleMapBundle:Form:places_autocomplete_widget.html.twig */
class __TwigTemplate_bffbfd35bbf44714bf7c95f9d10c6c63a7c6c99ca4a81075ad4603204691bd50 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'places_autocomplete_widget' => array($this, 'block_places_autocomplete_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cfe8b50bb10c32e20e3b7c051984773907c7a251e6f109c7c671603c3f3d3be3 = $this->env->getExtension("native_profiler");
        $__internal_cfe8b50bb10c32e20e3b7c051984773907c7a251e6f109c7c671603c3f3d3be3->enter($__internal_cfe8b50bb10c32e20e3b7c051984773907c7a251e6f109c7c671603c3f3d3be3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "IvoryGoogleMapBundle:Form:places_autocomplete_widget.html.twig"));

        // line 1
        $this->displayBlock('places_autocomplete_widget', $context, $blocks);
        
        $__internal_cfe8b50bb10c32e20e3b7c051984773907c7a251e6f109c7c671603c3f3d3be3->leave($__internal_cfe8b50bb10c32e20e3b7c051984773907c7a251e6f109c7c671603c3f3d3be3_prof);

    }

    public function block_places_autocomplete_widget($context, array $blocks = array())
    {
        $__internal_ec624fb63935692b081f080f9be3b1a912ae727f30f1b472e2eecaedac929185 = $this->env->getExtension("native_profiler");
        $__internal_ec624fb63935692b081f080f9be3b1a912ae727f30f1b472e2eecaedac929185->enter($__internal_ec624fb63935692b081f080f9be3b1a912ae727f30f1b472e2eecaedac929185_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "places_autocomplete_widget"));

        // line 2
        echo "    ";
        echo (isset($context["html"]) ? $context["html"] : $this->getContext($context, "html"));
        echo "
    ";
        // line 3
        echo (isset($context["javascripts"]) ? $context["javascripts"] : $this->getContext($context, "javascripts"));
        echo "
";
        
        $__internal_ec624fb63935692b081f080f9be3b1a912ae727f30f1b472e2eecaedac929185->leave($__internal_ec624fb63935692b081f080f9be3b1a912ae727f30f1b472e2eecaedac929185_prof);

    }

    public function getTemplateName()
    {
        return "IvoryGoogleMapBundle:Form:places_autocomplete_widget.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  40 => 3,  35 => 2,  23 => 1,);
    }
}
/* {% block places_autocomplete_widget %}*/
/*     {{ html | raw }}*/
/*     {{ javascripts | raw }}*/
/* {% endblock %}*/
/* */
