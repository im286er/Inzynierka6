<?php

/* :Szablony:login.html.twig */
class __TwigTemplate_a3c26a0550d883cb50207ef2aba69f3e8d3b1b3641517adfe3fd93797716cc19 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":Szablony:login.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d8007c6e6d49ef80ccbe951965c64667f829903d1b73a94cc68d4158edf979df = $this->env->getExtension("native_profiler");
        $__internal_d8007c6e6d49ef80ccbe951965c64667f829903d1b73a94cc68d4158edf979df->enter($__internal_d8007c6e6d49ef80ccbe951965c64667f829903d1b73a94cc68d4158edf979df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Szablony:login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d8007c6e6d49ef80ccbe951965c64667f829903d1b73a94cc68d4158edf979df->leave($__internal_d8007c6e6d49ef80ccbe951965c64667f829903d1b73a94cc68d4158edf979df_prof);

    }

    // line 4
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_c72c7fc0560447655a4b51d7e49532fae77c74e08dd40c3c1945f3d702a85e7b = $this->env->getExtension("native_profiler");
        $__internal_c72c7fc0560447655a4b51d7e49532fae77c74e08dd40c3c1945f3d702a85e7b->enter($__internal_c72c7fc0560447655a4b51d7e49532fae77c74e08dd40c3c1945f3d702a85e7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 5
        echo "    ";
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 6
            echo "        <div>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "</div>
    ";
        }
        // line 8
        echo "    ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "6794198_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_6794198_0") : $this->env->getExtension('asset')->getAssetUrl("_controller/css/6794198_login_1.css");
            // line 9
            echo "    <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        } else {
            // asset "6794198"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_6794198") : $this->env->getExtension('asset')->getAssetUrl("_controller/css/6794198.css");
            echo "    <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        }
        unset($context["asset_url"]);
        // line 11
        echo "    ";
        if (array_key_exists("form", $context)) {
            // line 12
            echo "        ";
            $this->env->getExtension('form')->renderer->setTheme((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), array(0 => "bootstrap_3_layout.html.twig"));
            // line 13
            echo "    ";
        }
        // line 14
        echo "
    <style>
        #hejka{
            position: relative;
            top:75px;
        }
    </style>

    <div class=\"container\" id=\"hejka\">
        <div class=\"row\">
            <div class=\"col-sm-6 col-md-4 col-md-offset-4\">
                <div class=\"account-wall\">
                    <img class=\"profile-img\" src=\"https://lh5.googleusercontent.com/-b0-k99FZlyE/AAAAAAAAAAI/AAAAAAAAAAA/eu7opA4byxI/photo.jpg?sz=120\" alt=\"\">
                    <form role=\"form\" class=\"form-signin\" action=\"";
        // line 27
        echo $this->env->getExtension('routing')->getPath("fos_user_security_check");
        echo "\"  method=\"post\">

                        <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 29
        echo twig_escape_filter($this->env, (isset($context["csrf_token"]) ? $context["csrf_token"] : $this->getContext($context, "csrf_token")), "html", null, true);
        echo "\" />

                        <label for=\"username\"></label>
                        <input type=\"text\" class=\"form-control\" id=\"username\" placeholder=\"Nazwa użytkownika lub email\" name=\"_username\" value=\"";
        // line 32
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" required=\"required\" />

                        <label for=\"password\"></label>
                        <input type=\"password\" class=\"form-control\" id=\"password\" placeholder=\"Hasło\" name=\"_password\" required=\"required\" />

                        <input type=\"submit\"  class=\"btn btn-lg btn-primary btn-block\" id=\"_submit\" name=\"_submit\" value=\"Zaloguj się\" />

                        <label class=\"checkbox-inline\" for=\"remember_me\"><input type=\"checkbox\"  id=\"remember_me\" name=\"_remember_me\" value=\"on\" />Zapamiętaj mnie</label>

                    </form>
                </div>
                <a href=\"";
        // line 43
        echo $this->env->getExtension('routing')->getPath("fos_user_registration_register");
        echo "\" class=\"text-center new-account\">Stwórz konto</a>
            </div>
        </div>
    </div>
";
        
        $__internal_c72c7fc0560447655a4b51d7e49532fae77c74e08dd40c3c1945f3d702a85e7b->leave($__internal_c72c7fc0560447655a4b51d7e49532fae77c74e08dd40c3c1945f3d702a85e7b_prof);

    }

    public function getTemplateName()
    {
        return ":Szablony:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 43,  103 => 32,  97 => 29,  92 => 27,  77 => 14,  74 => 13,  71 => 12,  68 => 11,  54 => 9,  49 => 8,  43 => 6,  40 => 5,  34 => 4,  11 => 1,);
    }
}
/* {% extends "base.html.twig" %}*/
/* */
/* */
/* {% block fos_user_content %}*/
/*     {% if error %}*/
/*         <div>{{ error.messageKey|trans(error.messageData, 'security') }}</div>*/
/*     {% endif %}*/
/*     {% stylesheets '@AppBundle/Resources/css/login.css' filter='cssrewrite' %}*/
/*     <link rel="stylesheet" href="{{ asset_url }}" />*/
/*     {% endstylesheets %}*/
/*     {% if form is defined %}*/
/*         {% form_theme form 'bootstrap_3_layout.html.twig' %}*/
/*     {% endif %}*/
/* */
/*     <style>*/
/*         #hejka{*/
/*             position: relative;*/
/*             top:75px;*/
/*         }*/
/*     </style>*/
/* */
/*     <div class="container" id="hejka">*/
/*         <div class="row">*/
/*             <div class="col-sm-6 col-md-4 col-md-offset-4">*/
/*                 <div class="account-wall">*/
/*                     <img class="profile-img" src="https://lh5.googleusercontent.com/-b0-k99FZlyE/AAAAAAAAAAI/AAAAAAAAAAA/eu7opA4byxI/photo.jpg?sz=120" alt="">*/
/*                     <form role="form" class="form-signin" action="{{ path("fos_user_security_check") }}"  method="post">*/
/* */
/*                         <input type="hidden" name="_csrf_token" value="{{ csrf_token }}" />*/
/* */
/*                         <label for="username"></label>*/
/*                         <input type="text" class="form-control" id="username" placeholder="Nazwa użytkownika lub email" name="_username" value="{{ last_username }}" required="required" />*/
/* */
/*                         <label for="password"></label>*/
/*                         <input type="password" class="form-control" id="password" placeholder="Hasło" name="_password" required="required" />*/
/* */
/*                         <input type="submit"  class="btn btn-lg btn-primary btn-block" id="_submit" name="_submit" value="Zaloguj się" />*/
/* */
/*                         <label class="checkbox-inline" for="remember_me"><input type="checkbox"  id="remember_me" name="_remember_me" value="on" />Zapamiętaj mnie</label>*/
/* */
/*                     </form>*/
/*                 </div>*/
/*                 <a href="{{ path('fos_user_registration_register') }}" class="text-center new-account">Stwórz konto</a>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* {% endblock fos_user_content %}*/
/* */
