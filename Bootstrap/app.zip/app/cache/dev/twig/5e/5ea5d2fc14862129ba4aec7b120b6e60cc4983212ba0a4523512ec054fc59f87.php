<?php

/* :Szablony:noweogloszenie.html.twig */
class __TwigTemplate_e6fa92c316729b9ce7c9ba7fd9ae4a996cc4d48929300e31f7880ee6f3b22497 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":Szablony:noweogloszenie.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cf45a9870afb18313aa17b7a5b60a51fad0ffb96093a277f88707a60abfd2040 = $this->env->getExtension("native_profiler");
        $__internal_cf45a9870afb18313aa17b7a5b60a51fad0ffb96093a277f88707a60abfd2040->enter($__internal_cf45a9870afb18313aa17b7a5b60a51fad0ffb96093a277f88707a60abfd2040_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Szablony:noweogloszenie.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cf45a9870afb18313aa17b7a5b60a51fad0ffb96093a277f88707a60abfd2040->leave($__internal_cf45a9870afb18313aa17b7a5b60a51fad0ffb96093a277f88707a60abfd2040_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_b909e70625ef718ae0ee1b810df8b7dd871aa609e4a80c3523d5f462c440bc21 = $this->env->getExtension("native_profiler");
        $__internal_b909e70625ef718ae0ee1b810df8b7dd871aa609e4a80c3523d5f462c440bc21->enter($__internal_b909e70625ef718ae0ee1b810df8b7dd871aa609e4a80c3523d5f462c440bc21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        echo "    ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "e3aff0d_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_e3aff0d_0") : $this->env->getExtension('asset')->getAssetUrl("_controller/css/e3aff0d_noweogloszenie_1.css");
            // line 5
            echo "    <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        } else {
            // asset "e3aff0d"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_e3aff0d") : $this->env->getExtension('asset')->getAssetUrl("_controller/css/e3aff0d.css");
            echo "    <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        }
        unset($context["asset_url"]);
        // line 7
        echo "
    ";
        // line 8
        $this->env->getExtension('form')->renderer->setTheme((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), array(0 => "bootstrap_3_layout.html.twig"));
        // line 9
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/bootstrap-datepicker-master/js/bootstrap-datepicker.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/bootstrap-datepicker-master/js/locales/bootstrap-datepicker.pl.js"), "html", null, true);
        echo "\"></script>
    <link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/bootstrap-datepicker-master/dist/css/bootstrap-datepicker.css"), "html", null, true);
        echo "\" />

    <div class=\"container\" >

        ";
        // line 15
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("class" => "form-horizontal style-form", "role" => "form")));
        echo "
        <div class=\"row\">
         <div class=\"page-header\">
            <h2>Nowe ogłoszenie</h2>
        </div>
        </div>
        <div class=\"row\">
            <h3 class=\"\">Podstawowe informacje</h3>
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"form-group\">
                        ";
        // line 26
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tytul", array()), 'label', array("label_attr" => array("class" => "col-sm-2 control-label "), "label" => "Tytuł(*):"));
        echo "
                        <div class=\"col-sm-4\">
                            ";
        // line 28
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tytul", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                            ";
        // line 29
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "tytul", array()), 'errors');
        echo "
                        </div>
                    </div>
                </div>
            </div>
            <div class=\"row\">
            <div class=\"col-xs-6\">
                    <div class=\"form-group\">
                            ";
        // line 37
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "wolneod", array()), 'label', array("label_attr" => array("class" => "col-md-4 control-label "), "label" => "Wolne od(*):"));
        echo "
                            <div class=\"col-sm-4\">
                                ";
        // line 39
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "wolneod", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                                ";
        // line 40
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "wolneod", array()), 'errors');
        echo "
                            </div>
                    </div>
                    <div class=\"form-group\">
                    ";
        // line 44
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "miasto", array()), 'label', array("label_attr" => array("class" => "col-md-4 control-label"), "label" => "Miasto(*):"));
        echo "
                        <div class=\"col-sm-4\">
                            ";
        // line 46
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "miasto", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                            ";
        // line 47
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "miasto", array()), 'errors');
        echo "
                        </div>
                    </div>
                    <div class=\"form-group\">
                        ";
        // line 51
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "dzielnica", array()), 'label', array("label_attr" => array("class" => "col-md-4 control-label"), "label" => "Dzielnica(*):"));
        echo "
                        <div class=\"col-sm-4\">
                            ";
        // line 53
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "dzielnica", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                            ";
        // line 54
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "dzielnica", array()), 'errors');
        echo "
                        </div>
                    </div>
                    <div class=\"form-group\">
                        ";
        // line 58
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "ulica", array()), 'label', array("label_attr" => array("class" => "col-md-4 control-label"), "label" => "Ulica(*):"));
        echo "
                        <div class=\"col-sm-4\">
                            ";
        // line 60
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "ulica", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                            ";
        // line 61
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "ulica", array()), 'errors');
        echo "
                        </div>
                    </div>
                    <div class=\"form-group\">
                        ";
        // line 65
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "typstancji", array()), 'label', array("label_attr" => array("class" => "col-md-4 control-label"), "label" => "Typ stancji(*):"));
        echo "
                        <div class=\"col-sm-4\">
                            ";
        // line 67
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "typstancji", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                            ";
        // line 68
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "typstancji", array()), 'errors');
        echo "
                        </div>
                    </div>
                    <div class=\"form-group\">
                        ";
        // line 72
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "czastrwania", array()), 'label', array("label_attr" => array("class" => "col-md-4 control-label"), "label" => "Czas trwania ogłoszenia(*):"));
        echo "
                        <div class=\"col-sm-4\">
                            ";
        // line 74
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "czastrwania", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                            ";
        // line 75
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "czastrwania", array()), 'errors');
        echo "
                        </div>
                    </div>
            </div>

            <div class=\"col-xs-6\">
                <div class=\"form-group\">
                    ";
        // line 82
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "typbudynku", array()), 'label', array("label_attr" => array("class" => "col-md-4 control-label"), "label" => "Typ budynku(*):"));
        echo "
                    <div class=\"col-sm-4\">
                        ";
        // line 84
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "typbudynku", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                        ";
        // line 85
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "typbudynku", array()), 'errors');
        echo "
                    </div>
                </div>
                <div class=\"form-group\">
                    ";
        // line 89
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pietro", array()), 'label', array("label_attr" => array("class" => "col-md-4 control-label"), "label" => "Piętro(*):"));
        echo "
                    <div class=\"col-sm-4\">
                        ";
        // line 91
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pietro", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                        ";
        // line 92
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pietro", array()), 'errors');
        echo "
                    </div>
                </div>
                <div class=\"form-group\">
                    ";
        // line 96
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "liczbapokoi", array()), 'label', array("label_attr" => array("class" => "col-md-4 control-label"), "label" => "Liczba pokoi(*):"));
        echo "
                    <div class=\"col-sm-4\">
                        ";
        // line 98
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "liczbapokoi", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                        ";
        // line 99
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "liczbapokoi", array()), 'errors');
        echo "
                    </div>
                </div>
                <div class=\"form-group\">
                    ";
        // line 103
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "maksliczbaosob", array()), 'label', array("label_attr" => array("class" => "col-md-4 control-label"), "label" => "Maksymalna liczba osób(*):"));
        echo "
                    <div class=\"col-sm-4\">
                        ";
        // line 105
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "maksliczbaosob", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                        ";
        // line 106
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "maksliczbaosob", array()), 'errors');
        echo "
                    </div>
                </div>
                <div class=\"form-group\">
                    ";
        // line 110
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "metraz", array()), 'label', array("label_attr" => array("class" => "col-md-4 control-label"), "label" => "Metraż(*):"));
        echo "<small>m<sup>2</sup></small>
                    <div class=\"col-sm-4\">
                        ";
        // line 112
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "metraz", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                        ";
        // line 113
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "metraz", array()), 'errors');
        echo "
                    </div>
                </div>
            </div>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-xs-6\">
                <div class=\"row\">
                    <h3 class=\"\">Wyposażenie</h3>
                    <div class=\"row\">
                        <div class=\"col-sm-2\">
                        ";
        // line 125
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "internet", array()), 'label', array("label_attr" => array("class" => ""), "label" => "Internet:"));
        echo "
                        ";
        // line 126
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "internet", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                        ";
        // line 127
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "internet", array()), 'errors');
        echo "
                        </div>
                        <div class=\"col-sm-2\">
                        ";
        // line 130
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "telefon", array()), 'label', array("label_attr" => array("class" => ""), "label" => "Telefon:"));
        echo "
                        ";
        // line 131
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "telefon", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                        ";
        // line 132
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "telefon", array()), 'errors');
        echo "
                        </div>
                        <div class=\"col-sm-2\">
                        ";
        // line 135
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "telewizor", array()), 'label', array("label_attr" => array("class" => ""), "label" => "Telewizor:"));
        echo "
                        ";
        // line 136
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "telewizor", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                        ";
        // line 137
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "telewizor", array()), 'errors');
        echo "
                        </div>
                        <div class=\"col-sm-2\">
                        ";
        // line 140
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "kablowka", array()), 'label', array("label_attr" => array("class" => ""), "label" => "TV-kablowa:"));
        echo "
                        ";
        // line 141
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "kablowka", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                        ";
        // line 142
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "kablowka", array()), 'errors');
        echo "
                        </div>
                    </div>

                    <div class=\"row\">
                        <div class=\"col-sm-2\">
                        ";
        // line 148
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pralka", array()), 'label', array("label_attr" => array("class" => ""), "label" => "Pralka:"));
        echo "
                        ";
        // line 149
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pralka", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                        ";
        // line 150
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pralka", array()), 'errors');
        echo "
                        </div>
                        <div class=\"col-sm-2\">
                        ";
        // line 153
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "lodowka", array()), 'label', array("label_attr" => array("class" => ""), "label" => "Lodówka:"));
        echo "
                        ";
        // line 154
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "lodowka", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                        ";
        // line 155
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "lodowka", array()), 'errors');
        echo "
                        </div>
                        <div class=\"col-sm-2\">
                        ";
        // line 158
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "prysznic", array()), 'label', array("label_attr" => array("class" => ""), "label" => "Prysznic:"));
        echo "
                        ";
        // line 159
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "prysznic", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                        ";
        // line 160
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "prysznic", array()), 'errors');
        echo "
                        </div>
                        <div class=\"col-sm-2\">
                        ";
        // line 163
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "wanna", array()), 'label', array("label_attr" => array("class" => ""), "label" => "Wanna:"));
        echo "
                        ";
        // line 164
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "wanna", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                        ";
        // line 165
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "wanna", array()), 'errors');
        echo "
                        </div>
                    </div>

                    <div class=\"row\">
                        <div class=\"col-sm-2\">
                        ";
        // line 171
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "balkon", array()), 'label', array("label_attr" => array("class" => ""), "label" => "Balkon:"));
        echo "
                        ";
        // line 172
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "balkon", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                        ";
        // line 173
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "balkon", array()), 'errors');
        echo "
                        </div>
                        <div class=\"col-sm-2\">
                        ";
        // line 176
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "taras", array()), 'label', array("label_attr" => array("class" => ""), "label" => "Taras:"));
        echo "
                        ";
        // line 177
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "taras", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                        ";
        // line 178
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "taras", array()), 'errors');
        echo "
                        </div>
                        <div class=\"col-sm-2\">
                        ";
        // line 181
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "parking", array()), 'label', array("label_attr" => array("class" => ""), "label" => "Parking:"));
        echo "
                        ";
        // line 182
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "parking", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                        ";
        // line 183
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "parking", array()), 'errors');
        echo "
                        </div>
                        <div class=\"col-sm-2\">
                        ";
        // line 186
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "garaz", array()), 'label', array("label_attr" => array("class" => ""), "label" => "Garaż:"));
        echo "
                        ";
        // line 187
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "garaz", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                        ";
        // line 188
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "garaz", array()), 'errors');
        echo "
                        </div>
                    </div>

                </div>
            </div>



            <div class=\"col-xs-6\">
                <div class=\"row\">
                    <p></p>
                    <h3 class=\"\">Współlokatorzy</h3>
                    <div class=\"row\">
                        <div class=\"col-sm-2\">
                            ";
        // line 203
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "kobiety", array()), 'label', array("label_attr" => array("class" => ""), "label" => "Kobiety:"));
        echo "
                            ";
        // line 204
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "kobiety", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                            ";
        // line 205
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "kobiety", array()), 'errors');
        echo "
                        </div>
                        <div class=\"col-sm-2\">
                            ";
        // line 208
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "mezczyzni", array()), 'label', array("label_attr" => array("class" => ""), "label" => "Mężczyźni:"));
        echo "
                            ";
        // line 209
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "mezczyzni", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                            ";
        // line 210
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "mezczyzni", array()), 'errors');
        echo "
                        </div>
                        <div class=\"col-sm-2\">
                            ";
        // line 213
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "palacy", array()), 'label', array("label_attr" => array("class" => ""), "label" => "Palący:"));
        echo "
                            ";
        // line 214
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "palacy", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                            ";
        // line 215
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "palacy", array()), 'errors');
        echo "
                        </div>
                    </div>

                    <div class=\"row\">
                        <div class=\"col-sm-2\">
                            ";
        // line 221
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "studenci", array()), 'label', array("label_attr" => array("class" => ""), "label" => "Studenci:"));
        echo "
                            ";
        // line 222
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "studenci", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                            ";
        // line 223
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "studenci", array()), 'errors');
        echo "
                        </div>
                        <div class=\"col-sm-2\">
                            ";
        // line 226
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pary", array()), 'label', array("label_attr" => array("class" => ""), "label" => "Pary:"));
        echo "
                            ";
        // line 227
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pary", array()), 'widget', array("attr" => array("class" => "")));
        echo "
                            ";
        // line 228
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pary", array()), 'errors');
        echo "
                        </div>
                        <div class=\"col-sm-2\">
                            ";
        // line 231
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pracujacy", array()), 'label', array("label_attr" => array("class" => ""), "label" => "Pracujący:"));
        echo "
                            ";
        // line 232
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pracujacy", array()), 'widget', array("attr" => array("id" => "")));
        echo "
                            ";
        // line 233
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pracujacy", array()), 'errors');
        echo "
                        </div>
                    </div>
                </div>
            </div>
            </div>
        <div class=\"row\">
            <div class=\"col-xs-6\">
                <div class=\"row\">
                <h3 class=\"\">Opłaty</h3>
                <div class=\"form-group\">
                    ";
        // line 244
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "cenazamiesiac", array()), 'label', array("label_attr" => array("class" => "col-md-4 control-label"), "label" => "Cena za miesiąc(*):"));
        echo "<small>zł</small>
                    <div class=\"col-sm-4\">
                        ";
        // line 246
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "cenazamiesiac", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                        ";
        // line 247
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "cenazamiesiac", array()), 'errors');
        echo "
                    </div>
                </div>
                <div class=\"form-group\">
                    ";
        // line 251
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "dodatkoweoplaty", array()), 'label', array("label_attr" => array("class" => "col-md-4 control-label"), "label" => "Dodatkowe oplaty na miesiąc(*):"));
        echo "<small>zł</small>
                    <div class=\"col-sm-4\">
                        ";
        // line 253
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "dodatkoweoplaty", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                        ";
        // line 254
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "dodatkoweoplaty", array()), 'errors');
        echo "
                    </div>
                </div>
                <div class=\"form-group\">
                    ";
        // line 258
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "kaucja", array()), 'label', array("label_attr" => array("class" => "col-md-4 control-label"), "label" => "Kaucja(*):"));
        echo "<small>zł</small>
                    <div class=\"col-sm-4\">
                        ";
        // line 260
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "kaucja", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                        ";
        // line 261
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "kaucja", array()), 'errors');
        echo "
                    </div>
                </div>
                </div>
            </div>

            <div id=\"galeria\">
                <div class=\"col-xs-6\">
                    <div class=\"panel panel-default\">
                        <div class=\"panel-heading\"><strong><h4>Galeria</h4></strong></div>

                        <!-- jQuery
                           ====================================================================== -->
                        <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js\"></script>

                        <!-- Fine Uploader Gallery CSS file
                        ====================================================================== -->
                        <link href=\"";
        // line 278
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/fineuploader/fine-uploader-new.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">

                        <!-- Fine Uploader jQuery JS file
                        ====================================================================== -->
                        <script src=\"";
        // line 282
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/fineuploader/jquery.fine-uploader.js"), "html", null, true);
        echo "\"></script>

                        <!-- Fine Uploader Gallery template
                        ====================================================================== -->
                        <script type=\"text/template\" id=\"qq-template-gallery\">
                            <div class=\"qq-uploader-selector qq-uploader qq-gallery\" qq-drop-area-text=\"Upuść zdjęcia tutaj \">

                                <div class=\"qq-upload-button-selector qq-upload-button\">
                                    <div>Dodaj zdjęcie</div>
                                </div>

                                <div class=\"qq-upload-message\">
                                    <div>(Maks. liczba zdjęć: 4, Dozwolone formaty: png, jpg, jpeg)</div>
                                </div>

                                <div class=\"qq-total-progress-bar-container-selector qq-total-progress-bar-container\">
                                    <div class=\"qq-total-progress-bar-selector qq-progress-bar qq-total-progress-bar\" role=\"progressbar\" aria-valuenow=\"0\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>
                                </div>
                                <div class=\"qq-upload-drop-area-selector qq-upload-drop-area\" qq-hide-dropzone>
                                    <span class=\"qq-upload-drop-area-text-selector\"></span>
                                </div>
            <span class=\"qq-drop-processing-selector qq-drop-processing\">
                <span>Analizowanie przesyłanych plików...</span>
                <span class=\"qq-drop-processing-spinner-selector qq-drop-processing-spinner\"></span>
            </span>
                                <ul class=\"qq-upload-list-selector qq-upload-list\" role=\"region\" aria-live=\"polite\" aria-relevant=\"additions removals\">
                                    <li>
                                        <span role=\"status\" class=\"qq-upload-status-text-selector qq-upload-status-text\"></span>
                                        <div class=\"qq-progress-bar-container-selector qq-progress-bar-container\">
                                            <div role=\"progressbar\" aria-valuenow=\"0\" aria-valuemin=\"0\" aria-valuemax=\"100\" class=\"qq-progress-bar-selector qq-progress-bar\"></div>
                                        </div>
                                        <span class=\"qq-upload-spinner-selector qq-upload-spinner\"></span>
                                        <div class=\"qq-thumbnail-wrapper\">
                                            <img class=\"qq-thumbnail-selector\" qq-max-size=\"120\" qq-server-scale>
                                        </div>
                                        <button type=\"button\" class=\"qq-upload-cancel-selector qq-upload-cancel\">X</button>
                                        <button type=\"button\" class=\"qq-upload-retry-selector qq-upload-retry\">
                                            <span class=\"qq-btn qq-retry-icon\" aria-label=\"Retry\"></span>
                                            Ponów
                                        </button>

                                        <div class=\"qq-file-info\">
                                            <div class=\"qq-file-name\">
                                                <span class=\"qq-upload-file-selector qq-upload-file\"></span>
                                                <span class=\"qq-edit-filename-icon-selector qq-edit-filename-icon\" aria-label=\"Edit filename\"></span>
                                            </div>
                                            <input class=\"qq-edit-filename-selector qq-edit-filename\" tabindex=\"0\" type=\"text\">
                                            <span class=\"qq-upload-size-selector qq-upload-size\"></span>
                                            <button type=\"button\" class=\"qq-btn qq-upload-delete-selector qq-upload-delete\">
                                                <span class=\"qq-btn qq-delete-icon\" aria-label=\"Delete\"></span>
                                            </button>
                                            <button type=\"button\" class=\"qq-btn qq-upload-pause-selector qq-upload-pause\">
                                                <span class=\"qq-btn qq-pause-icon\" aria-label=\"Pause\"></span>
                                            </button>
                                            <button type=\"button\" class=\"qq-btn qq-upload-continue-selector qq-upload-continue\">
                                                <span class=\"qq-btn qq-continue-icon\" aria-label=\"Continue\"></span>
                                            </button>
                                        </div>
                                    </li>
                                </ul>

                                <dialog class=\"qq-alert-dialog-selector\">
                                    <div class=\"qq-dialog-message-selector\"></div>
                                    <div class=\"qq-dialog-buttons\">
                                        <button type=\"button\" class=\"qq-cancel-button-selector\">Zamknij</button>
                                    </div>
                                </dialog>

                                <dialog class=\"qq-confirm-dialog-selector\">
                                    <div class=\"qq-dialog-message-selector\"></div>
                                    <div class=\"qq-dialog-buttons\">
                                        <button type=\"button\" class=\"qq-cancel-button-selector\">Nie</button>
                                        <button type=\"button\" class=\"qq-ok-button-selector\">Tak</button>
                                    </div>
                                </dialog>

                                <dialog class=\"qq-prompt-dialog-selector\">
                                    <div class=\"qq-dialog-message-selector\"></div>
                                    <input type=\"text\">
                                    <div class=\"qq-dialog-buttons\">
                                        <button type=\"button\" class=\"qq-cancel-button-selector\">Anuluj</button>
                                        <button type=\"button\" class=\"qq-ok-button-selector\">Ok</button>
                                    </div>
                                </dialog>
                            </div>
                        </script>




                        <!-- Fine Uploader DOM Element
                        ====================================================================== -->
                        <div id=\"fine-uploader-gallery\"></div>

                        <!-- Your code to create an instance of Fine Uploader and bind to the DOM/template
                        ====================================================================== -->
                        <script>
                            \$('#fine-uploader-gallery').fineUploader({
                                template: 'qq-template-gallery',
                                request: {
                                    endpoint: \"";
        // line 382
        echo twig_escape_filter($this->env, $this->env->getExtension('oneup_uploader')->endpoint("gallery"), "html", null, true);
        echo "\"
                                },
                                thumbnails: {
                                    placeholders: {
                                        waitingPath: '/source/placeholders/waiting-generic.png',
                                        notAvailablePath: '/source/placeholders/not_available-generic.png'
                                    }
                                },
                                validation: {
                                    itemLimit: 4,
                                    allowedExtensions: ['jpeg', 'jpg', 'png']
                                },
                               // deleteFile: {
                                //    enabled: true,
                                 //   forceConfirm: true,
                                 //   endpoint: \"";
        // line 397
        echo twig_escape_filter($this->env, $this->env->getExtension('oneup_uploader')->endpoint("gallery"), "html", null, true);
        echo "\"
                                //}
                            });
                        </script>


                    </div>
                </div>
            </div>
        </div>
        <div class=\"col-xs-6\">
            <div class=\"row\">
                <div class=\"form-group\">
                    ";
        // line 410
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "dodatkoweinformacje", array()), 'label', array("label_attr" => array("for" => "comment"), "label" => "Dodatkowe informacje:"));
        echo "
                    ";
        // line 411
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "dodatkoweinformacje", array()), 'widget', array("attr" => array("class" => "form-control counted", "id" => "area")));
        echo "
                    <h6 class=\"col-sm-offset-5\" id=\"counter\">Pozostało 255 znaków</h6>
                    ";
        // line 413
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "dodatkoweinformacje", array()), 'errors');
        echo "

                </div>
            </div>

        </div>
        <div class=\"col-xs-12\">
            <div class=\"form-group\">
                <div class=\"col-sm-9 col-sm-offset-4\">
                    <button id=\"wystaw\" type=\"submit\" class=\"btn btn-primary btn-lg\" name=\"signup\" value=\"Sign up\">Wystaw ogłoszenie</button>
                </div>
            </div>
        </div>


        ";
        // line 428
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
    </div>


<script>
    /**
     *
     * jquery.charcounter.js version 1.2
     * requires jQuery version 1.2 or higher
     * Copyright (c) 2007 Tom Deater (http://www.tomdeater.com)
     * Licensed under the MIT License:
     * http://www.opensource.org/licenses/mit-license.php
     *
     */

    (function(\$) {
        /**
         * attaches a character counter to each textarea element in the jQuery object
         * usage: \$(\"#myTextArea\").charCounter(max, settings);
         */

        \$.fn.charCounter = function (max, settings) {
            max = max || 100;
            settings = \$.extend({
                container: \"<span></span>\",
                classname: \"charcounter\",
                format: \"(Pozostało %1 znaków)\",
                pulse: true,
                delay: 0
            }, settings);
            var p, timeout;

            function count(el, container) {
                el = \$(el);
                if (el.val().length > max) {
                    el.val(el.val().substring(0, max));
                    if (settings.pulse && !p) {
                        pulse(container, true);
                    };
                };
                if (settings.delay > 0) {
                    if (timeout) {
                        window.clearTimeout(timeout);
                    }
                    timeout = window.setTimeout(function () {
                        container.html(settings.format.replace(/%1/, (max - el.val().length)));
                    }, settings.delay);
                } else {
                    container.html(settings.format.replace(/%1/, (max - el.val().length)));
                }
            };

            function pulse(el, again) {
                if (p) {
                    window.clearTimeout(p);
                    p = null;
                };
                el.animate({ opacity: 0.1 }, 100, function () {
                    \$(this).animate({ opacity: 1.0 }, 100);
                });
                if (again) {
                    p = window.setTimeout(function () { pulse(el) }, 200);
                };
            };

            return this.each(function () {
                var container;
                if (!settings.container.match(/^<.+>\$/)) {
                    // use existing element to hold counter message
                    container = \$(settings.container);
                } else {
                    // append element to hold counter message (clean up old element first)
                    \$(this).next(\".\" + settings.classname).remove();
                    container = \$(settings.container)
                            .insertAfter(this)
                            .addClass(settings.classname);
                }
                \$(this)
                        .unbind(\".charCounter\")
                        .bind(\"keydown.charCounter\", function () { count(this, container); })
                        .bind(\"keypress.charCounter\", function () { count(this, container); })
                        .bind(\"keyup.charCounter\", function () { count(this, container); })
                        .bind(\"focus.charCounter\", function () { count(this, container); })
                        .bind(\"mouseover.charCounter\", function () { count(this, container); })
                        .bind(\"mouseout.charCounter\", function () { count(this, container); })
                        .bind(\"paste.charCounter\", function () {
                            var me = this;
                            setTimeout(function () { count(me, container); }, 10);
                        });
                if (this.addEventListener) {
                    this.addEventListener('input', function () { count(this, container); }, false);
                };
                count(this, container);
            });
        };

    })(jQuery);

    \$(function() {
        \$(\".counted\").charCounter(255,{container: \"#counter\"});
    });

</script>

";
        
        $__internal_b909e70625ef718ae0ee1b810df8b7dd871aa609e4a80c3523d5f462c440bc21->leave($__internal_b909e70625ef718ae0ee1b810df8b7dd871aa609e4a80c3523d5f462c440bc21_prof);

    }

    public function getTemplateName()
    {
        return ":Szablony:noweogloszenie.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  814 => 428,  796 => 413,  791 => 411,  787 => 410,  771 => 397,  753 => 382,  650 => 282,  643 => 278,  623 => 261,  619 => 260,  614 => 258,  607 => 254,  603 => 253,  598 => 251,  591 => 247,  587 => 246,  582 => 244,  568 => 233,  564 => 232,  560 => 231,  554 => 228,  550 => 227,  546 => 226,  540 => 223,  536 => 222,  532 => 221,  523 => 215,  519 => 214,  515 => 213,  509 => 210,  505 => 209,  501 => 208,  495 => 205,  491 => 204,  487 => 203,  469 => 188,  465 => 187,  461 => 186,  455 => 183,  451 => 182,  447 => 181,  441 => 178,  437 => 177,  433 => 176,  427 => 173,  423 => 172,  419 => 171,  410 => 165,  406 => 164,  402 => 163,  396 => 160,  392 => 159,  388 => 158,  382 => 155,  378 => 154,  374 => 153,  368 => 150,  364 => 149,  360 => 148,  351 => 142,  347 => 141,  343 => 140,  337 => 137,  333 => 136,  329 => 135,  323 => 132,  319 => 131,  315 => 130,  309 => 127,  305 => 126,  301 => 125,  286 => 113,  282 => 112,  277 => 110,  270 => 106,  266 => 105,  261 => 103,  254 => 99,  250 => 98,  245 => 96,  238 => 92,  234 => 91,  229 => 89,  222 => 85,  218 => 84,  213 => 82,  203 => 75,  199 => 74,  194 => 72,  187 => 68,  183 => 67,  178 => 65,  171 => 61,  167 => 60,  162 => 58,  155 => 54,  151 => 53,  146 => 51,  139 => 47,  135 => 46,  130 => 44,  123 => 40,  119 => 39,  114 => 37,  103 => 29,  99 => 28,  94 => 26,  80 => 15,  73 => 11,  69 => 10,  64 => 9,  62 => 8,  59 => 7,  45 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block fos_user_content %}*/
/*     {% stylesheets '@AppBundle/Resources/css/noweogloszenie.css' filter='cssrewrite' %}*/
/*     <link rel="stylesheet" href="{{ asset_url }}" />*/
/*     {% endstylesheets %}*/
/* */
/*     {% form_theme form 'bootstrap_3_layout.html.twig' %}*/
/*     <script src="{{ asset('bundles/bootstrap-datepicker-master/js/bootstrap-datepicker.js') }}"></script>*/
/*     <script src="{{ asset('bundles/bootstrap-datepicker-master/js/locales/bootstrap-datepicker.pl.js') }}"></script>*/
/*     <link rel="stylesheet" href="{{ asset('bundles/bootstrap-datepicker-master/dist/css/bootstrap-datepicker.css') }}" />*/
/* */
/*     <div class="container" >*/
/* */
/*         {{ form_start(form, {'attr': {'class': 'form-horizontal style-form', 'role': 'form'}}) }}*/
/*         <div class="row">*/
/*          <div class="page-header">*/
/*             <h2>Nowe ogłoszenie</h2>*/
/*         </div>*/
/*         </div>*/
/*         <div class="row">*/
/*             <h3 class="">Podstawowe informacje</h3>*/
/*             <div class="row">*/
/*                 <div class="col-sm-12">*/
/*                     <div class="form-group">*/
/*                         {{ form_label(form.tytul, 'Tytuł(*):', {'label_attr': {'class': 'col-sm-2 control-label '}}) }}*/
/*                         <div class="col-sm-4">*/
/*                             {{ form_widget(form.tytul, {'attr': {'class':'form-control'}}) }}*/
/*                             {{ form_errors(form.tytul) }}*/
/*                         </div>*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*             <div class="row">*/
/*             <div class="col-xs-6">*/
/*                     <div class="form-group">*/
/*                             {{ form_label(form.wolneod, 'Wolne od(*):', {'label_attr': {'class': 'col-md-4 control-label '}}) }}*/
/*                             <div class="col-sm-4">*/
/*                                 {{ form_widget(form.wolneod, {'attr': {'class':''}}) }}*/
/*                                 {{ form_errors(form.wolneod) }}*/
/*                             </div>*/
/*                     </div>*/
/*                     <div class="form-group">*/
/*                     {{ form_label(form.miasto, 'Miasto(*):', {'label_attr': {'class': 'col-md-4 control-label'}}) }}*/
/*                         <div class="col-sm-4">*/
/*                             {{ form_widget(form.miasto, {'attr': {'class':'form-control'}}) }}*/
/*                             {{ form_errors(form.miasto) }}*/
/*                         </div>*/
/*                     </div>*/
/*                     <div class="form-group">*/
/*                         {{ form_label(form.dzielnica, 'Dzielnica(*):', {'label_attr': {'class': 'col-md-4 control-label'}}) }}*/
/*                         <div class="col-sm-4">*/
/*                             {{ form_widget(form.dzielnica, {'attr': {'class':'form-control'}}) }}*/
/*                             {{ form_errors(form.dzielnica) }}*/
/*                         </div>*/
/*                     </div>*/
/*                     <div class="form-group">*/
/*                         {{ form_label(form.ulica, 'Ulica(*):', {'label_attr': {'class': 'col-md-4 control-label'}}) }}*/
/*                         <div class="col-sm-4">*/
/*                             {{ form_widget(form.ulica, {'attr': {'class':'form-control'}}) }}*/
/*                             {{ form_errors(form.ulica) }}*/
/*                         </div>*/
/*                     </div>*/
/*                     <div class="form-group">*/
/*                         {{ form_label(form.typstancji, 'Typ stancji(*):', {'label_attr': {'class': 'col-md-4 control-label'}}) }}*/
/*                         <div class="col-sm-4">*/
/*                             {{ form_widget(form.typstancji, {'attr': {'class':'form-control'}}) }}*/
/*                             {{ form_errors(form.typstancji) }}*/
/*                         </div>*/
/*                     </div>*/
/*                     <div class="form-group">*/
/*                         {{ form_label(form.czastrwania, 'Czas trwania ogłoszenia(*):', {'label_attr': {'class': 'col-md-4 control-label'}}) }}*/
/*                         <div class="col-sm-4">*/
/*                             {{ form_widget(form.czastrwania, {'attr': {'class':'form-control'}}) }}*/
/*                             {{ form_errors(form.czastrwania) }}*/
/*                         </div>*/
/*                     </div>*/
/*             </div>*/
/* */
/*             <div class="col-xs-6">*/
/*                 <div class="form-group">*/
/*                     {{ form_label(form.typbudynku, 'Typ budynku(*):', {'label_attr': {'class': 'col-md-4 control-label'}}) }}*/
/*                     <div class="col-sm-4">*/
/*                         {{ form_widget(form.typbudynku, {'attr': {'class':'form-control'}}) }}*/
/*                         {{ form_errors(form.typbudynku) }}*/
/*                     </div>*/
/*                 </div>*/
/*                 <div class="form-group">*/
/*                     {{ form_label(form.pietro, 'Piętro(*):', {'label_attr': {'class': 'col-md-4 control-label'}}) }}*/
/*                     <div class="col-sm-4">*/
/*                         {{ form_widget(form.pietro, {'attr': {'class':'form-control'}}) }}*/
/*                         {{ form_errors(form.pietro) }}*/
/*                     </div>*/
/*                 </div>*/
/*                 <div class="form-group">*/
/*                     {{ form_label(form.liczbapokoi, 'Liczba pokoi(*):', {'label_attr': {'class': 'col-md-4 control-label'}}) }}*/
/*                     <div class="col-sm-4">*/
/*                         {{ form_widget(form.liczbapokoi, {'attr': {'class':'form-control'}}) }}*/
/*                         {{ form_errors(form.liczbapokoi) }}*/
/*                     </div>*/
/*                 </div>*/
/*                 <div class="form-group">*/
/*                     {{ form_label(form.maksliczbaosob, 'Maksymalna liczba osób(*):', {'label_attr': {'class': 'col-md-4 control-label'}}) }}*/
/*                     <div class="col-sm-4">*/
/*                         {{ form_widget(form.maksliczbaosob, {'attr': {'class':'form-control'}}) }}*/
/*                         {{ form_errors(form.maksliczbaosob) }}*/
/*                     </div>*/
/*                 </div>*/
/*                 <div class="form-group">*/
/*                     {{ form_label(form.metraz, 'Metraż(*):', {'label_attr': {'class': 'col-md-4 control-label'}}) }}<small>m<sup>2</sup></small>*/
/*                     <div class="col-sm-4">*/
/*                         {{ form_widget(form.metraz, {'attr': {'class':'form-control'}}) }}*/
/*                         {{ form_errors(form.metraz) }}*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*             </div>*/
/*         </div>*/
/*         <div class="row">*/
/*             <div class="col-xs-6">*/
/*                 <div class="row">*/
/*                     <h3 class="">Wyposażenie</h3>*/
/*                     <div class="row">*/
/*                         <div class="col-sm-2">*/
/*                         {{ form_label(form.internet, 'Internet:', {'label_attr': {'class': ''}}) }}*/
/*                         {{ form_widget(form.internet, {'attr': {'class':''}}) }}*/
/*                         {{ form_errors(form.internet) }}*/
/*                         </div>*/
/*                         <div class="col-sm-2">*/
/*                         {{ form_label(form.telefon, 'Telefon:', {'label_attr': {'class': ''}}) }}*/
/*                         {{ form_widget(form.telefon, {'attr': {'class':''}}) }}*/
/*                         {{ form_errors(form.telefon) }}*/
/*                         </div>*/
/*                         <div class="col-sm-2">*/
/*                         {{ form_label(form.telewizor, 'Telewizor:', {'label_attr': {'class': ''}}) }}*/
/*                         {{ form_widget(form.telewizor, {'attr': {'class':''}}) }}*/
/*                         {{ form_errors(form.telewizor) }}*/
/*                         </div>*/
/*                         <div class="col-sm-2">*/
/*                         {{ form_label(form.kablowka, 'TV-kablowa:', {'label_attr': {'class': ''}}) }}*/
/*                         {{ form_widget(form.kablowka, {'attr': {'class':''}}) }}*/
/*                         {{ form_errors(form.kablowka) }}*/
/*                         </div>*/
/*                     </div>*/
/* */
/*                     <div class="row">*/
/*                         <div class="col-sm-2">*/
/*                         {{ form_label(form.pralka, 'Pralka:', {'label_attr': {'class': ''}}) }}*/
/*                         {{ form_widget(form.pralka, {'attr': {'class':''}}) }}*/
/*                         {{ form_errors(form.pralka) }}*/
/*                         </div>*/
/*                         <div class="col-sm-2">*/
/*                         {{ form_label(form.lodowka, 'Lodówka:', {'label_attr': {'class': ''}}) }}*/
/*                         {{ form_widget(form.lodowka, {'attr': {'class':''}}) }}*/
/*                         {{ form_errors(form.lodowka) }}*/
/*                         </div>*/
/*                         <div class="col-sm-2">*/
/*                         {{ form_label(form.prysznic, 'Prysznic:', {'label_attr': {'class': ''}}) }}*/
/*                         {{ form_widget(form.prysznic, {'attr': {'class':''}}) }}*/
/*                         {{ form_errors(form.prysznic) }}*/
/*                         </div>*/
/*                         <div class="col-sm-2">*/
/*                         {{ form_label(form.wanna, 'Wanna:', {'label_attr': {'class': ''}}) }}*/
/*                         {{ form_widget(form.wanna, {'attr': {'class':''}}) }}*/
/*                         {{ form_errors(form.wanna) }}*/
/*                         </div>*/
/*                     </div>*/
/* */
/*                     <div class="row">*/
/*                         <div class="col-sm-2">*/
/*                         {{ form_label(form.balkon, 'Balkon:', {'label_attr': {'class': ''}}) }}*/
/*                         {{ form_widget(form.balkon, {'attr': {'class':''}}) }}*/
/*                         {{ form_errors(form.balkon) }}*/
/*                         </div>*/
/*                         <div class="col-sm-2">*/
/*                         {{ form_label(form.taras, 'Taras:', {'label_attr': {'class': ''}}) }}*/
/*                         {{ form_widget(form.taras, {'attr': {'class':''}}) }}*/
/*                         {{ form_errors(form.taras) }}*/
/*                         </div>*/
/*                         <div class="col-sm-2">*/
/*                         {{ form_label(form.parking, 'Parking:', {'label_attr': {'class': ''}}) }}*/
/*                         {{ form_widget(form.parking, {'attr': {'class':''}}) }}*/
/*                         {{ form_errors(form.parking) }}*/
/*                         </div>*/
/*                         <div class="col-sm-2">*/
/*                         {{ form_label(form.garaz, 'Garaż:', {'label_attr': {'class': ''}}) }}*/
/*                         {{ form_widget(form.garaz, {'attr': {'class':''}}) }}*/
/*                         {{ form_errors(form.garaz) }}*/
/*                         </div>*/
/*                     </div>*/
/* */
/*                 </div>*/
/*             </div>*/
/* */
/* */
/* */
/*             <div class="col-xs-6">*/
/*                 <div class="row">*/
/*                     <p></p>*/
/*                     <h3 class="">Współlokatorzy</h3>*/
/*                     <div class="row">*/
/*                         <div class="col-sm-2">*/
/*                             {{ form_label(form.kobiety, 'Kobiety:', {'label_attr': {'class': ''}}) }}*/
/*                             {{ form_widget(form.kobiety, {'attr': {'class':''}}) }}*/
/*                             {{ form_errors(form.kobiety) }}*/
/*                         </div>*/
/*                         <div class="col-sm-2">*/
/*                             {{ form_label(form.mezczyzni, 'Mężczyźni:', {'label_attr': {'class': ''}}) }}*/
/*                             {{ form_widget(form.mezczyzni, {'attr': {'class':''}}) }}*/
/*                             {{ form_errors(form.mezczyzni) }}*/
/*                         </div>*/
/*                         <div class="col-sm-2">*/
/*                             {{ form_label(form.palacy, 'Palący:', {'label_attr': {'class': ''}}) }}*/
/*                             {{ form_widget(form.palacy, {'attr': {'class':''}}) }}*/
/*                             {{ form_errors(form.palacy) }}*/
/*                         </div>*/
/*                     </div>*/
/* */
/*                     <div class="row">*/
/*                         <div class="col-sm-2">*/
/*                             {{ form_label(form.studenci, 'Studenci:', {'label_attr': {'class': ''}}) }}*/
/*                             {{ form_widget(form.studenci, {'attr': {'class':''}}) }}*/
/*                             {{ form_errors(form.studenci) }}*/
/*                         </div>*/
/*                         <div class="col-sm-2">*/
/*                             {{ form_label(form.pary, 'Pary:', {'label_attr': {'class': ''}}) }}*/
/*                             {{ form_widget(form.pary, {'attr': {'class':''}}) }}*/
/*                             {{ form_errors(form.pary) }}*/
/*                         </div>*/
/*                         <div class="col-sm-2">*/
/*                             {{ form_label(form.pracujacy, 'Pracujący:', {'label_attr': {'class': ''}}) }}*/
/*                             {{ form_widget(form.pracujacy, {'attr': {'id':''}}) }}*/
/*                             {{ form_errors(form.pracujacy) }}*/
/*                         </div>*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*             </div>*/
/*         <div class="row">*/
/*             <div class="col-xs-6">*/
/*                 <div class="row">*/
/*                 <h3 class="">Opłaty</h3>*/
/*                 <div class="form-group">*/
/*                     {{ form_label(form.cenazamiesiac, 'Cena za miesiąc(*):', {'label_attr': {'class': 'col-md-4 control-label'}}) }}<small>zł</small>*/
/*                     <div class="col-sm-4">*/
/*                         {{ form_widget(form.cenazamiesiac, {'attr': {'class':'form-control'}}) }}*/
/*                         {{ form_errors(form.cenazamiesiac) }}*/
/*                     </div>*/
/*                 </div>*/
/*                 <div class="form-group">*/
/*                     {{ form_label(form.dodatkoweoplaty, 'Dodatkowe oplaty na miesiąc(*):', {'label_attr': {'class': 'col-md-4 control-label'}}) }}<small>zł</small>*/
/*                     <div class="col-sm-4">*/
/*                         {{ form_widget(form.dodatkoweoplaty, {'attr': {'class':'form-control'}}) }}*/
/*                         {{ form_errors(form.dodatkoweoplaty) }}*/
/*                     </div>*/
/*                 </div>*/
/*                 <div class="form-group">*/
/*                     {{ form_label(form.kaucja, 'Kaucja(*):', {'label_attr': {'class': 'col-md-4 control-label'}}) }}<small>zł</small>*/
/*                     <div class="col-sm-4">*/
/*                         {{ form_widget(form.kaucja, {'attr': {'class':'form-control'}}) }}*/
/*                         {{ form_errors(form.kaucja) }}*/
/*                     </div>*/
/*                 </div>*/
/*                 </div>*/
/*             </div>*/
/* */
/*             <div id="galeria">*/
/*                 <div class="col-xs-6">*/
/*                     <div class="panel panel-default">*/
/*                         <div class="panel-heading"><strong><h4>Galeria</h4></strong></div>*/
/* */
/*                         <!-- jQuery*/
/*                            ====================================================================== -->*/
/*                         <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>*/
/* */
/*                         <!-- Fine Uploader Gallery CSS file*/
/*                         ====================================================================== -->*/
/*                         <link href="{{ asset('bundles/fineuploader/fine-uploader-new.css') }}" rel="stylesheet">*/
/* */
/*                         <!-- Fine Uploader jQuery JS file*/
/*                         ====================================================================== -->*/
/*                         <script src="{{ asset('bundles/fineuploader/jquery.fine-uploader.js') }}"></script>*/
/* */
/*                         <!-- Fine Uploader Gallery template*/
/*                         ====================================================================== -->*/
/*                         <script type="text/template" id="qq-template-gallery">*/
/*                             <div class="qq-uploader-selector qq-uploader qq-gallery" qq-drop-area-text="Upuść zdjęcia tutaj ">*/
/* */
/*                                 <div class="qq-upload-button-selector qq-upload-button">*/
/*                                     <div>Dodaj zdjęcie</div>*/
/*                                 </div>*/
/* */
/*                                 <div class="qq-upload-message">*/
/*                                     <div>(Maks. liczba zdjęć: 4, Dozwolone formaty: png, jpg, jpeg)</div>*/
/*                                 </div>*/
/* */
/*                                 <div class="qq-total-progress-bar-container-selector qq-total-progress-bar-container">*/
/*                                     <div class="qq-total-progress-bar-selector qq-progress-bar qq-total-progress-bar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>*/
/*                                 </div>*/
/*                                 <div class="qq-upload-drop-area-selector qq-upload-drop-area" qq-hide-dropzone>*/
/*                                     <span class="qq-upload-drop-area-text-selector"></span>*/
/*                                 </div>*/
/*             <span class="qq-drop-processing-selector qq-drop-processing">*/
/*                 <span>Analizowanie przesyłanych plików...</span>*/
/*                 <span class="qq-drop-processing-spinner-selector qq-drop-processing-spinner"></span>*/
/*             </span>*/
/*                                 <ul class="qq-upload-list-selector qq-upload-list" role="region" aria-live="polite" aria-relevant="additions removals">*/
/*                                     <li>*/
/*                                         <span role="status" class="qq-upload-status-text-selector qq-upload-status-text"></span>*/
/*                                         <div class="qq-progress-bar-container-selector qq-progress-bar-container">*/
/*                                             <div role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" class="qq-progress-bar-selector qq-progress-bar"></div>*/
/*                                         </div>*/
/*                                         <span class="qq-upload-spinner-selector qq-upload-spinner"></span>*/
/*                                         <div class="qq-thumbnail-wrapper">*/
/*                                             <img class="qq-thumbnail-selector" qq-max-size="120" qq-server-scale>*/
/*                                         </div>*/
/*                                         <button type="button" class="qq-upload-cancel-selector qq-upload-cancel">X</button>*/
/*                                         <button type="button" class="qq-upload-retry-selector qq-upload-retry">*/
/*                                             <span class="qq-btn qq-retry-icon" aria-label="Retry"></span>*/
/*                                             Ponów*/
/*                                         </button>*/
/* */
/*                                         <div class="qq-file-info">*/
/*                                             <div class="qq-file-name">*/
/*                                                 <span class="qq-upload-file-selector qq-upload-file"></span>*/
/*                                                 <span class="qq-edit-filename-icon-selector qq-edit-filename-icon" aria-label="Edit filename"></span>*/
/*                                             </div>*/
/*                                             <input class="qq-edit-filename-selector qq-edit-filename" tabindex="0" type="text">*/
/*                                             <span class="qq-upload-size-selector qq-upload-size"></span>*/
/*                                             <button type="button" class="qq-btn qq-upload-delete-selector qq-upload-delete">*/
/*                                                 <span class="qq-btn qq-delete-icon" aria-label="Delete"></span>*/
/*                                             </button>*/
/*                                             <button type="button" class="qq-btn qq-upload-pause-selector qq-upload-pause">*/
/*                                                 <span class="qq-btn qq-pause-icon" aria-label="Pause"></span>*/
/*                                             </button>*/
/*                                             <button type="button" class="qq-btn qq-upload-continue-selector qq-upload-continue">*/
/*                                                 <span class="qq-btn qq-continue-icon" aria-label="Continue"></span>*/
/*                                             </button>*/
/*                                         </div>*/
/*                                     </li>*/
/*                                 </ul>*/
/* */
/*                                 <dialog class="qq-alert-dialog-selector">*/
/*                                     <div class="qq-dialog-message-selector"></div>*/
/*                                     <div class="qq-dialog-buttons">*/
/*                                         <button type="button" class="qq-cancel-button-selector">Zamknij</button>*/
/*                                     </div>*/
/*                                 </dialog>*/
/* */
/*                                 <dialog class="qq-confirm-dialog-selector">*/
/*                                     <div class="qq-dialog-message-selector"></div>*/
/*                                     <div class="qq-dialog-buttons">*/
/*                                         <button type="button" class="qq-cancel-button-selector">Nie</button>*/
/*                                         <button type="button" class="qq-ok-button-selector">Tak</button>*/
/*                                     </div>*/
/*                                 </dialog>*/
/* */
/*                                 <dialog class="qq-prompt-dialog-selector">*/
/*                                     <div class="qq-dialog-message-selector"></div>*/
/*                                     <input type="text">*/
/*                                     <div class="qq-dialog-buttons">*/
/*                                         <button type="button" class="qq-cancel-button-selector">Anuluj</button>*/
/*                                         <button type="button" class="qq-ok-button-selector">Ok</button>*/
/*                                     </div>*/
/*                                 </dialog>*/
/*                             </div>*/
/*                         </script>*/
/* */
/* */
/* */
/* */
/*                         <!-- Fine Uploader DOM Element*/
/*                         ====================================================================== -->*/
/*                         <div id="fine-uploader-gallery"></div>*/
/* */
/*                         <!-- Your code to create an instance of Fine Uploader and bind to the DOM/template*/
/*                         ====================================================================== -->*/
/*                         <script>*/
/*                             $('#fine-uploader-gallery').fineUploader({*/
/*                                 template: 'qq-template-gallery',*/
/*                                 request: {*/
/*                                     endpoint: "{{ oneup_uploader_endpoint('gallery') }}"*/
/*                                 },*/
/*                                 thumbnails: {*/
/*                                     placeholders: {*/
/*                                         waitingPath: '/source/placeholders/waiting-generic.png',*/
/*                                         notAvailablePath: '/source/placeholders/not_available-generic.png'*/
/*                                     }*/
/*                                 },*/
/*                                 validation: {*/
/*                                     itemLimit: 4,*/
/*                                     allowedExtensions: ['jpeg', 'jpg', 'png']*/
/*                                 },*/
/*                                // deleteFile: {*/
/*                                 //    enabled: true,*/
/*                                  //   forceConfirm: true,*/
/*                                  //   endpoint: "{{ oneup_uploader_endpoint('gallery') }}"*/
/*                                 //}*/
/*                             });*/
/*                         </script>*/
/* */
/* */
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*         <div class="col-xs-6">*/
/*             <div class="row">*/
/*                 <div class="form-group">*/
/*                     {{ form_label(form.dodatkoweinformacje, 'Dodatkowe informacje:', {'label_attr': {'for': 'comment'}}) }}*/
/*                     {{ form_widget(form.dodatkoweinformacje, {'attr': {'class':'form-control counted', 'id':'area'}}) }}*/
/*                     <h6 class="col-sm-offset-5" id="counter">Pozostało 255 znaków</h6>*/
/*                     {{ form_errors(form.dodatkoweinformacje) }}*/
/* */
/*                 </div>*/
/*             </div>*/
/* */
/*         </div>*/
/*         <div class="col-xs-12">*/
/*             <div class="form-group">*/
/*                 <div class="col-sm-9 col-sm-offset-4">*/
/*                     <button id="wystaw" type="submit" class="btn btn-primary btn-lg" name="signup" value="Sign up">Wystaw ogłoszenie</button>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/* */
/* */
/*         {{ form_end(form) }}*/
/*     </div>*/
/* */
/* */
/* <script>*/
/*     /***/
/*      **/
/*      * jquery.charcounter.js version 1.2*/
/*      * requires jQuery version 1.2 or higher*/
/*      * Copyright (c) 2007 Tom Deater (http://www.tomdeater.com)*/
/*      * Licensed under the MIT License:*/
/*      * http://www.opensource.org/licenses/mit-license.php*/
/*      **/
/*      *//* */
/* */
/*     (function($) {*/
/*         /***/
/*          * attaches a character counter to each textarea element in the jQuery object*/
/*          * usage: $("#myTextArea").charCounter(max, settings);*/
/*          *//* */
/* */
/*         $.fn.charCounter = function (max, settings) {*/
/*             max = max || 100;*/
/*             settings = $.extend({*/
/*                 container: "<span></span>",*/
/*                 classname: "charcounter",*/
/*                 format: "(Pozostało %1 znaków)",*/
/*                 pulse: true,*/
/*                 delay: 0*/
/*             }, settings);*/
/*             var p, timeout;*/
/* */
/*             function count(el, container) {*/
/*                 el = $(el);*/
/*                 if (el.val().length > max) {*/
/*                     el.val(el.val().substring(0, max));*/
/*                     if (settings.pulse && !p) {*/
/*                         pulse(container, true);*/
/*                     };*/
/*                 };*/
/*                 if (settings.delay > 0) {*/
/*                     if (timeout) {*/
/*                         window.clearTimeout(timeout);*/
/*                     }*/
/*                     timeout = window.setTimeout(function () {*/
/*                         container.html(settings.format.replace(/%1/, (max - el.val().length)));*/
/*                     }, settings.delay);*/
/*                 } else {*/
/*                     container.html(settings.format.replace(/%1/, (max - el.val().length)));*/
/*                 }*/
/*             };*/
/* */
/*             function pulse(el, again) {*/
/*                 if (p) {*/
/*                     window.clearTimeout(p);*/
/*                     p = null;*/
/*                 };*/
/*                 el.animate({ opacity: 0.1 }, 100, function () {*/
/*                     $(this).animate({ opacity: 1.0 }, 100);*/
/*                 });*/
/*                 if (again) {*/
/*                     p = window.setTimeout(function () { pulse(el) }, 200);*/
/*                 };*/
/*             };*/
/* */
/*             return this.each(function () {*/
/*                 var container;*/
/*                 if (!settings.container.match(/^<.+>$/)) {*/
/*                     // use existing element to hold counter message*/
/*                     container = $(settings.container);*/
/*                 } else {*/
/*                     // append element to hold counter message (clean up old element first)*/
/*                     $(this).next("." + settings.classname).remove();*/
/*                     container = $(settings.container)*/
/*                             .insertAfter(this)*/
/*                             .addClass(settings.classname);*/
/*                 }*/
/*                 $(this)*/
/*                         .unbind(".charCounter")*/
/*                         .bind("keydown.charCounter", function () { count(this, container); })*/
/*                         .bind("keypress.charCounter", function () { count(this, container); })*/
/*                         .bind("keyup.charCounter", function () { count(this, container); })*/
/*                         .bind("focus.charCounter", function () { count(this, container); })*/
/*                         .bind("mouseover.charCounter", function () { count(this, container); })*/
/*                         .bind("mouseout.charCounter", function () { count(this, container); })*/
/*                         .bind("paste.charCounter", function () {*/
/*                             var me = this;*/
/*                             setTimeout(function () { count(me, container); }, 10);*/
/*                         });*/
/*                 if (this.addEventListener) {*/
/*                     this.addEventListener('input', function () { count(this, container); }, false);*/
/*                 };*/
/*                 count(this, container);*/
/*             });*/
/*         };*/
/* */
/*     })(jQuery);*/
/* */
/*     $(function() {*/
/*         $(".counted").charCounter(255,{container: "#counter"});*/
/*     });*/
/* */
/* </script>*/
/* */
/* {% endblock fos_user_content %}*/
