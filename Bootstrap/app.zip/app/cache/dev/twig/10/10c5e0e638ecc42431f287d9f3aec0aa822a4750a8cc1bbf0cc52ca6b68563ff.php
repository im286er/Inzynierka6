<?php

/* :Szablony:profiluzytkownika.html.twig */
class __TwigTemplate_4be15124bc41f508e0734b3915d9652abefcab885cefd1f0b06a58af586f1209 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":Szablony:profiluzytkownika.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_63a46495ac8678c2f0a891a366f69b52d7ca9795d02d434479b63224d42f7c98 = $this->env->getExtension("native_profiler");
        $__internal_63a46495ac8678c2f0a891a366f69b52d7ca9795d02d434479b63224d42f7c98->enter($__internal_63a46495ac8678c2f0a891a366f69b52d7ca9795d02d434479b63224d42f7c98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Szablony:profiluzytkownika.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_63a46495ac8678c2f0a891a366f69b52d7ca9795d02d434479b63224d42f7c98->leave($__internal_63a46495ac8678c2f0a891a366f69b52d7ca9795d02d434479b63224d42f7c98_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_c444c99e5609429a11f7102cb443893daf8ac4084cef293867566fbd8e6cc089 = $this->env->getExtension("native_profiler");
        $__internal_c444c99e5609429a11f7102cb443893daf8ac4084cef293867566fbd8e6cc089->enter($__internal_c444c99e5609429a11f7102cb443893daf8ac4084cef293867566fbd8e6cc089_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        echo "    ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "b17d528_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_b17d528_0") : $this->env->getExtension('asset')->getAssetUrl("_controller/css/b17d528_profiluzytkownika_1.css");
            // line 5
            echo "    <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        } else {
            // asset "b17d528"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_b17d528") : $this->env->getExtension('asset')->getAssetUrl("_controller/css/b17d528.css");
            echo "    <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        }
        unset($context["asset_url"]);
        // line 7
        echo "

    <div class=\"container\" id=\"kontener\">
        <div class=\"row\">
            <div class=\"col-xs-12 col-sm-6 col-md-6 col-sm-offset-3\">
                <div class=\"well well-sm\">
                    <div class=\"row\">
                        <div class=\"col-sm-6 col-md-4\">
                            <img src=\"https://ssl.gstatic.com/accounts/ui/avatar_2x.png\" alt=\"\" class=\"img-rounded img-responsive\" />
                        </div>
                        <div class=\"col-sm-6 col-md-8\">
                            <h4>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "html", null, true);
        echo "</h4>
                            <p></p>
                                <i class=\"glyphicon glyphicon-user\"></i> ";
        // line 20
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "imie", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "nazwisko", array()), "html", null, true);
        echo "
                                <br />
                                <i class=\"glyphicon glyphicon-envelope\"></i> ";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array()), "html", null, true);
        echo "
                                <br />
                                <i class=\"glyphicon glyphicon-phone\"></i> ";
        // line 24
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "telefon", array()), "html", null, true);
        echo "
                        </div>
                        <div class=\"col-sm-6 col-sm-offset-5\"><button class=\"btn btn-primary\"><a href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("_ofertyuser", array("id" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "id", array()))), "html", null, true);
        echo "\" class=\"text-center new-account\">Wystawione ogłoszenia użytkownika ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "html", null, true);
        echo " </a></button></div>
                    </div>
                </div>
            </div>
        </div>
        <div class=\"row\">
            <h1 class=\"page-header text-center\">Komentarze</h1>
            <!-- /col-sm-12 -->
            <div class=\"col-sm-12\">
                <div class=\"col-sm-1\">
                    <div class=\"thumbnail\">
                        <a href=\"";
        // line 37
        echo $this->env->getExtension('routing')->getPath("_profil", array("id" => "x"));
        echo "\"><img class=\"img-responsive user-photo\" src=\"https://ssl.gstatic.com/accounts/ui/avatar_2x.png\"></a>
                    </div><!-- /thumbnail -->
                </div><!-- /col-sm-1 -->

                <div class=\"col-sm-11\">
                    <div class=\"panel panel-default\">
                        <div class=\"panel-heading\">
                            <strong>użytkownik</strong>
                            <span class=\"text-muted col-sm-offset-9\">dodano 5 dni temu</span>
                        </div>
                        <div class=\"panel-body\">
                            <p>komentarz</p>
                        </div>
                    </div>
                </div>
                <button class=\"btn btn-primary col-sm-2 col-sm-offset-10\" id=\"confirm\">Dodaj komentarz</button>
            </div>
        </div>
    </div>

    <div class=\"modal fade\" id=\"myModal\" role=\"dialog\">
        <div class=\"modal-dialog\">
            <!-- Modal content-->
            <div class=\"modal-content\">
                <div class=\"modal-header\" >
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"></button>
                    <h4 class=\"text-center\">Nowy komentarz</h4>
                </div>
                <div class=\"modal-body\">
                    ";
        // line 66
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("method" => "post", "attr" => array("class" => "form-horizontal")));
        echo "
                    <div class=\"form-group\">
                        ";
        // line 68
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "komentarz", array()), 'label', array("label_attr" => array()));
        echo "
                        ";
        // line 69
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "komentarz", array()), 'widget', array("attr" => array("class" => "form-control counted", "id" => "area")));
        echo "
                        <h6 class=\"col-sm-offset-9\" id=\"counter\">Pozostało 255 znaków</h6>
                        ";
        // line 71
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "komentarz", array()), 'errors');
        echo "
                    </div>
                    ";
        // line 73
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
                        <button type=\"submit\" class=\"btn btn-danger btn-default pull-left\" data-dismiss=\"modal\"></span>
                            <a class=\"usun\" href=\"#\">Anuluj</a></button>
                        <button type=\"submit\" class=\"btn btn-primary btn-default pull-right\" data-dismiss=\"modal\">Dodaj</button>
                </div>
            </div>

        </div>
    </div>


    <script>
        \$(\"#confirm\").click(function(){
            \$(\"#myModal\").modal();
        });
    </script>

    <script>
        /**
         *
         * jquery.charcounter.js version 1.2
         * requires jQuery version 1.2 or higher
         * Copyright (c) 2007 Tom Deater (http://www.tomdeater.com)
         * Licensed under the MIT License:
         * http://www.opensource.org/licenses/mit-license.php
         *
         */

        (function(\$) {
            /**
             * attaches a character counter to each textarea element in the jQuery object
             * usage: \$(\"#myTextArea\").charCounter(max, settings);
             */

            \$.fn.charCounter = function (max, settings) {
                max = max || 100;
                settings = \$.extend({
                    container: \"<span></span>\",
                    classname: \"charcounter\",
                    format: \"(Pozostało %1 znaków)\",
                    pulse: true,
                    delay: 0
                }, settings);
                var p, timeout;

                function count(el, container) {
                    el = \$(el);
                    if (el.val().length > max) {
                        el.val(el.val().substring(0, max));
                        if (settings.pulse && !p) {
                            pulse(container, true);
                        };
                    };
                    if (settings.delay > 0) {
                        if (timeout) {
                            window.clearTimeout(timeout);
                        }
                        timeout = window.setTimeout(function () {
                            container.html(settings.format.replace(/%1/, (max - el.val().length)));
                        }, settings.delay);
                    } else {
                        container.html(settings.format.replace(/%1/, (max - el.val().length)));
                    }
                };

                function pulse(el, again) {
                    if (p) {
                        window.clearTimeout(p);
                        p = null;
                    };
                    el.animate({ opacity: 0.1 }, 100, function () {
                        \$(this).animate({ opacity: 1.0 }, 100);
                    });
                    if (again) {
                        p = window.setTimeout(function () { pulse(el) }, 200);
                    };
                };

                return this.each(function () {
                    var container;
                    if (!settings.container.match(/^<.+>\$/)) {
                        // use existing element to hold counter message
                        container = \$(settings.container);
                    } else {
                        // append element to hold counter message (clean up old element first)
                        \$(this).next(\".\" + settings.classname).remove();
                        container = \$(settings.container)
                                .insertAfter(this)
                                .addClass(settings.classname);
                    }
                    \$(this)
                            .unbind(\".charCounter\")
                            .bind(\"keydown.charCounter\", function () { count(this, container); })
                            .bind(\"keypress.charCounter\", function () { count(this, container); })
                            .bind(\"keyup.charCounter\", function () { count(this, container); })
                            .bind(\"focus.charCounter\", function () { count(this, container); })
                            .bind(\"mouseover.charCounter\", function () { count(this, container); })
                            .bind(\"mouseout.charCounter\", function () { count(this, container); })
                            .bind(\"paste.charCounter\", function () {
                                var me = this;
                                setTimeout(function () { count(me, container); }, 10);
                            });
                    if (this.addEventListener) {
                        this.addEventListener('input', function () { count(this, container); }, false);
                    };
                    count(this, container);
                });
            };

        })(jQuery);

        \$(function() {
            \$(\".counted\").charCounter(255,{container: \"#counter\"});
        });

    </script>
";
        
        $__internal_c444c99e5609429a11f7102cb443893daf8ac4084cef293867566fbd8e6cc089->leave($__internal_c444c99e5609429a11f7102cb443893daf8ac4084cef293867566fbd8e6cc089_prof);

    }

    public function getTemplateName()
    {
        return ":Szablony:profiluzytkownika.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  161 => 73,  156 => 71,  151 => 69,  147 => 68,  142 => 66,  110 => 37,  94 => 26,  89 => 24,  84 => 22,  77 => 20,  72 => 18,  59 => 7,  45 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block fos_user_content %}*/
/*     {% stylesheets '@AppBundle/Resources/css/profiluzytkownika.css' filter='cssrewrite' %}*/
/*     <link rel="stylesheet" href="{{ asset_url }}" />*/
/*     {% endstylesheets %}*/
/* */
/* */
/*     <div class="container" id="kontener">*/
/*         <div class="row">*/
/*             <div class="col-xs-12 col-sm-6 col-md-6 col-sm-offset-3">*/
/*                 <div class="well well-sm">*/
/*                     <div class="row">*/
/*                         <div class="col-sm-6 col-md-4">*/
/*                             <img src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png" alt="" class="img-rounded img-responsive" />*/
/*                         </div>*/
/*                         <div class="col-sm-6 col-md-8">*/
/*                             <h4>{{ user.username }}</h4>*/
/*                             <p></p>*/
/*                                 <i class="glyphicon glyphicon-user"></i> {{ user.imie }} {{ user.nazwisko }}*/
/*                                 <br />*/
/*                                 <i class="glyphicon glyphicon-envelope"></i> {{ user.email }}*/
/*                                 <br />*/
/*                                 <i class="glyphicon glyphicon-phone"></i> {{ user.telefon }}*/
/*                         </div>*/
/*                         <div class="col-sm-6 col-sm-offset-5"><button class="btn btn-primary"><a href="{{ path ('_ofertyuser', {'id': user.id}) }}" class="text-center new-account">Wystawione ogłoszenia użytkownika {{ user.username }} </a></button></div>*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*         <div class="row">*/
/*             <h1 class="page-header text-center">Komentarze</h1>*/
/*             <!-- /col-sm-12 -->*/
/*             <div class="col-sm-12">*/
/*                 <div class="col-sm-1">*/
/*                     <div class="thumbnail">*/
/*                         <a href="{{ path('_profil', {'id': 'x'}) }}"><img class="img-responsive user-photo" src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png"></a>*/
/*                     </div><!-- /thumbnail -->*/
/*                 </div><!-- /col-sm-1 -->*/
/* */
/*                 <div class="col-sm-11">*/
/*                     <div class="panel panel-default">*/
/*                         <div class="panel-heading">*/
/*                             <strong>użytkownik</strong>*/
/*                             <span class="text-muted col-sm-offset-9">dodano 5 dni temu</span>*/
/*                         </div>*/
/*                         <div class="panel-body">*/
/*                             <p>komentarz</p>*/
/*                         </div>*/
/*                     </div>*/
/*                 </div>*/
/*                 <button class="btn btn-primary col-sm-2 col-sm-offset-10" id="confirm">Dodaj komentarz</button>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* */
/*     <div class="modal fade" id="myModal" role="dialog">*/
/*         <div class="modal-dialog">*/
/*             <!-- Modal content-->*/
/*             <div class="modal-content">*/
/*                 <div class="modal-header" >*/
/*                     <button type="button" class="close" data-dismiss="modal"></button>*/
/*                     <h4 class="text-center">Nowy komentarz</h4>*/
/*                 </div>*/
/*                 <div class="modal-body">*/
/*                     {{ form_start(form, {'method': 'post', 'attr': {'class': 'form-horizontal'}}) }}*/
/*                     <div class="form-group">*/
/*                         {{ form_label(form.komentarz, '', {'label_attr': {}}) }}*/
/*                         {{ form_widget(form.komentarz, {'attr': {'class':'form-control counted', 'id':'area'}}) }}*/
/*                         <h6 class="col-sm-offset-9" id="counter">Pozostało 255 znaków</h6>*/
/*                         {{ form_errors(form.komentarz) }}*/
/*                     </div>*/
/*                     {{ form_end(form) }}*/
/*                         <button type="submit" class="btn btn-danger btn-default pull-left" data-dismiss="modal"></span>*/
/*                             <a class="usun" href="#">Anuluj</a></button>*/
/*                         <button type="submit" class="btn btn-primary btn-default pull-right" data-dismiss="modal">Dodaj</button>*/
/*                 </div>*/
/*             </div>*/
/* */
/*         </div>*/
/*     </div>*/
/* */
/* */
/*     <script>*/
/*         $("#confirm").click(function(){*/
/*             $("#myModal").modal();*/
/*         });*/
/*     </script>*/
/* */
/*     <script>*/
/*         /***/
/*          **/
/*          * jquery.charcounter.js version 1.2*/
/*          * requires jQuery version 1.2 or higher*/
/*          * Copyright (c) 2007 Tom Deater (http://www.tomdeater.com)*/
/*          * Licensed under the MIT License:*/
/*          * http://www.opensource.org/licenses/mit-license.php*/
/*          **/
/*          *//* */
/* */
/*         (function($) {*/
/*             /***/
/*              * attaches a character counter to each textarea element in the jQuery object*/
/*              * usage: $("#myTextArea").charCounter(max, settings);*/
/*              *//* */
/* */
/*             $.fn.charCounter = function (max, settings) {*/
/*                 max = max || 100;*/
/*                 settings = $.extend({*/
/*                     container: "<span></span>",*/
/*                     classname: "charcounter",*/
/*                     format: "(Pozostało %1 znaków)",*/
/*                     pulse: true,*/
/*                     delay: 0*/
/*                 }, settings);*/
/*                 var p, timeout;*/
/* */
/*                 function count(el, container) {*/
/*                     el = $(el);*/
/*                     if (el.val().length > max) {*/
/*                         el.val(el.val().substring(0, max));*/
/*                         if (settings.pulse && !p) {*/
/*                             pulse(container, true);*/
/*                         };*/
/*                     };*/
/*                     if (settings.delay > 0) {*/
/*                         if (timeout) {*/
/*                             window.clearTimeout(timeout);*/
/*                         }*/
/*                         timeout = window.setTimeout(function () {*/
/*                             container.html(settings.format.replace(/%1/, (max - el.val().length)));*/
/*                         }, settings.delay);*/
/*                     } else {*/
/*                         container.html(settings.format.replace(/%1/, (max - el.val().length)));*/
/*                     }*/
/*                 };*/
/* */
/*                 function pulse(el, again) {*/
/*                     if (p) {*/
/*                         window.clearTimeout(p);*/
/*                         p = null;*/
/*                     };*/
/*                     el.animate({ opacity: 0.1 }, 100, function () {*/
/*                         $(this).animate({ opacity: 1.0 }, 100);*/
/*                     });*/
/*                     if (again) {*/
/*                         p = window.setTimeout(function () { pulse(el) }, 200);*/
/*                     };*/
/*                 };*/
/* */
/*                 return this.each(function () {*/
/*                     var container;*/
/*                     if (!settings.container.match(/^<.+>$/)) {*/
/*                         // use existing element to hold counter message*/
/*                         container = $(settings.container);*/
/*                     } else {*/
/*                         // append element to hold counter message (clean up old element first)*/
/*                         $(this).next("." + settings.classname).remove();*/
/*                         container = $(settings.container)*/
/*                                 .insertAfter(this)*/
/*                                 .addClass(settings.classname);*/
/*                     }*/
/*                     $(this)*/
/*                             .unbind(".charCounter")*/
/*                             .bind("keydown.charCounter", function () { count(this, container); })*/
/*                             .bind("keypress.charCounter", function () { count(this, container); })*/
/*                             .bind("keyup.charCounter", function () { count(this, container); })*/
/*                             .bind("focus.charCounter", function () { count(this, container); })*/
/*                             .bind("mouseover.charCounter", function () { count(this, container); })*/
/*                             .bind("mouseout.charCounter", function () { count(this, container); })*/
/*                             .bind("paste.charCounter", function () {*/
/*                                 var me = this;*/
/*                                 setTimeout(function () { count(me, container); }, 10);*/
/*                             });*/
/*                     if (this.addEventListener) {*/
/*                         this.addEventListener('input', function () { count(this, container); }, false);*/
/*                     };*/
/*                     count(this, container);*/
/*                 });*/
/*             };*/
/* */
/*         })(jQuery);*/
/* */
/*         $(function() {*/
/*             $(".counted").charCounter(255,{container: "#counter"});*/
/*         });*/
/* */
/*     </script>*/
/* {% endblock fos_user_content %}*/
