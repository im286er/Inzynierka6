<?php

/* :Szablony:profil.html.twig */
class __TwigTemplate_a8a7b968f477e221ce867f49b3484002a6fa96e38d0c7b7a6b957a3503301569 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":Szablony:profil.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_33acc80149bbae5c3f8a413199c29554dd02f1b34b536962f904eb0495da8014 = $this->env->getExtension("native_profiler");
        $__internal_33acc80149bbae5c3f8a413199c29554dd02f1b34b536962f904eb0495da8014->enter($__internal_33acc80149bbae5c3f8a413199c29554dd02f1b34b536962f904eb0495da8014_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Szablony:profil.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_33acc80149bbae5c3f8a413199c29554dd02f1b34b536962f904eb0495da8014->leave($__internal_33acc80149bbae5c3f8a413199c29554dd02f1b34b536962f904eb0495da8014_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_4908410ca6e9de677eea23d359e23aae099813ccc729056facc0d9fbe7e6177c = $this->env->getExtension("native_profiler");
        $__internal_4908410ca6e9de677eea23d359e23aae099813ccc729056facc0d9fbe7e6177c->enter($__internal_4908410ca6e9de677eea23d359e23aae099813ccc729056facc0d9fbe7e6177c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        echo "    ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "4a15a66_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_4a15a66_0") : $this->env->getExtension('asset')->getAssetUrl("_controller/css/4a15a66_profil_1.css");
            // line 5
            echo "    <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        } else {
            // asset "4a15a66"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_4a15a66") : $this->env->getExtension('asset')->getAssetUrl("_controller/css/4a15a66.css");
            echo "    <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        }
        unset($context["asset_url"]);
        // line 7
        echo "    <script>
        \$(document).ready(function() {
            \$(\".btn-pref .btn\").click(function () {
                \$(\".btn-pref .btn\").removeClass(\"btn-primary\").addClass(\"btn-default\");
                // \$(\".tab\").addClass(\"active\"); // instead of this do the below
                \$(this).removeClass(\"btn-default\").addClass(\"btn-primary\");
            });
        });
    </script>

    <div class=\"fos_user_user_show\">
        <div class=\"container\" id=\"kontener\">
            <div class=\"col-lg-12 col-sm-12\">
                <div class=\"card hovercard\">
                    <div class=\"card-background\">
                        <img class=\"card-bkimg\" alt=\"\" src=\"https://ssl.gstatic.com/accounts/ui/avatar_2x.png\">
                        <!-- http://lorempixel.com/850/280/people/9/ -->
                    </div>
                    <div class=\"useravatar\">
                        <img alt=\"\" src=\"https://ssl.gstatic.com/accounts/ui/avatar_2x.png\">
                    </div>
                    <div class=\"card-info\"> <span class=\"card-title\">";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "html", null, true);
        echo "</span>

                    </div>
                </div>
                <div class=\"btn-pref btn-group btn-group-justified btn-group-lg\" role=\"group\" aria-label=\"...\">
                    <div class=\"btn-group\" role=\"group\">
                        <button type=\"button\" id=\"stars\" class=\"btn btn-primary\" href=\"#tab1\" data-toggle=\"tab\"><span class=\"glyphicon glyphicon-user\" aria-hidden=\"true\"></span>
                            <div class=\"hidden-xs\">O mnie</div>
                        </button>
                    </div>
                    <div class=\"btn-group\" role=\"group\">
                        <button type=\"button\" id=\"favorites\" class=\"btn btn-default\" href=\"#tab2\" data-toggle=\"tab\"><span class=\"glyphicon glyphicon-heart\" aria-hidden=\"true\"></span>
                            <div class=\"hidden-xs\">Obserwowane oferty</div>
                        </button>
                    </div>
                    <div class=\"btn-group\" role=\"group\">
                        <button type=\"button\" id=\"following\" class=\"btn btn-default\" href=\"#tab3\" data-toggle=\"tab\"><span class=\"glyphicon glyphicon-comment\" aria-hidden=\"true\"></span>
                            <div class=\"hidden-xs\">Komentarze</div>
                        </button>
                    </div>
                </div>

                <div class=\"well\">
                    <div class=\"tab-content\">
                        <div class=\"tab-pane fade in active\" id=\"tab1\">
                            <div class=\"col-sm-3 text-center\">
                                <div class=\"row\"><a href=\"";
        // line 54
        echo $this->env->getExtension('routing')->getPath("fos_user_profile_edit");
        echo "\" class=\"text-center new-account\"><span class=\"glyphicon glyphicon-wrench\"></span> Edytuj dane osobowe</a></div>
                                <div class=\"row\"><a href=\"";
        // line 55
        echo $this->env->getExtension('routing')->getPath("fos_user_change_password");
        echo "\" class=\"text-center new-account\"><span class=\"glyphicon glyphicon-wrench\"></span> Zmień hasło</a></div>
                                <div class=\"row\"><a href=\"";
        // line 56
        echo $this->env->getExtension('routing')->getPath("App_MojeWystawioneOgloszenia");
        echo "\" class=\"text-center new-account\"><span class=\"glyphicon glyphicon-list-alt\"></span> Wystawione ogłoszenia</a></div>
                            </div>
                            <div class=\"col-sm-3\" id=\"tab11\">
                                <h4>Informacje o mnie</h4>
                                <p>Imie i nazwisko: ";
        // line 60
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "imie", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "nazwisko", array()), "html", null, true);
        echo "</p>
                                <p>Nazwa użytkownika: ";
        // line 61
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "html", null, true);
        echo "</p>
                            </div>
                            <div >
                                <h4>Dane kontaktowe</h4>
                                <p>Adres email: ";
        // line 65
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array()), "html", null, true);
        echo "</p>
                                <p>Numer telefonu: ";
        // line 66
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "telefon", array()), "html", null, true);
        echo "</p>
                            </div>
                        </div>
                        <div class=\"tab-pane fade in\" id=\"tab2\">
                            <table class=\"table\">
                                <tr>
                                    <th>Tytuł</th>
                                    <th>Kategoria</th>
                                    <th>Cena</th>
                                </tr>
                                <tr>
                                        <td><a href=\"#\"> tytul</a></td>
                                        <td>kategoria</td>
                                        <td>zł/miesiąc</td>
                                        <td>
                                            <a href=\"#\"><span class=\"glyphicon glyphicon-trash\"></span> Usuń</a>
                                        </td>
                                </tr>
                            </table>
                        </div>
                        <div class=\"tab-pane fade in\" id=\"tab3\">
                            <ul class=\"media-list\">
                                <li class=\"media\">
                                    <a class=\"pull-left\" href=\"";
        // line 89
        echo $this->env->getExtension('routing')->getPath("_profil", array("id" => "x"));
        echo "\">
                                        <img class=\"media-object img-circle\" src=\"https://ssl.gstatic.com/accounts/ui/avatar_2x.png\" alt=\"profile\">
                                    </a>
                                    <div class=\"media-body\">
                                        <div class=\"well well-lg\">
                                            <h4 class=\"media-heading text-uppercase reviews\">Kajoj</h4>
                                            <p class=\"media-comment\">
                                                Ale zajebiste, co?
                                            </p>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
";
        
        $__internal_4908410ca6e9de677eea23d359e23aae099813ccc729056facc0d9fbe7e6177c->leave($__internal_4908410ca6e9de677eea23d359e23aae099813ccc729056facc0d9fbe7e6177c_prof);

    }

    public function getTemplateName()
    {
        return ":Szablony:profil.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  169 => 89,  143 => 66,  139 => 65,  132 => 61,  126 => 60,  119 => 56,  115 => 55,  111 => 54,  82 => 28,  59 => 7,  45 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "base.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/*     {% stylesheets '@AppBundle/Resources/css/profil.css' filter='cssrewrite' %}*/
/*     <link rel="stylesheet" href="{{ asset_url }}" />*/
/*     {% endstylesheets %}*/
/*     <script>*/
/*         $(document).ready(function() {*/
/*             $(".btn-pref .btn").click(function () {*/
/*                 $(".btn-pref .btn").removeClass("btn-primary").addClass("btn-default");*/
/*                 // $(".tab").addClass("active"); // instead of this do the below*/
/*                 $(this).removeClass("btn-default").addClass("btn-primary");*/
/*             });*/
/*         });*/
/*     </script>*/
/* */
/*     <div class="fos_user_user_show">*/
/*         <div class="container" id="kontener">*/
/*             <div class="col-lg-12 col-sm-12">*/
/*                 <div class="card hovercard">*/
/*                     <div class="card-background">*/
/*                         <img class="card-bkimg" alt="" src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png">*/
/*                         <!-- http://lorempixel.com/850/280/people/9/ -->*/
/*                     </div>*/
/*                     <div class="useravatar">*/
/*                         <img alt="" src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png">*/
/*                     </div>*/
/*                     <div class="card-info"> <span class="card-title">{{ user.username }}</span>*/
/* */
/*                     </div>*/
/*                 </div>*/
/*                 <div class="btn-pref btn-group btn-group-justified btn-group-lg" role="group" aria-label="...">*/
/*                     <div class="btn-group" role="group">*/
/*                         <button type="button" id="stars" class="btn btn-primary" href="#tab1" data-toggle="tab"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>*/
/*                             <div class="hidden-xs">O mnie</div>*/
/*                         </button>*/
/*                     </div>*/
/*                     <div class="btn-group" role="group">*/
/*                         <button type="button" id="favorites" class="btn btn-default" href="#tab2" data-toggle="tab"><span class="glyphicon glyphicon-heart" aria-hidden="true"></span>*/
/*                             <div class="hidden-xs">Obserwowane oferty</div>*/
/*                         </button>*/
/*                     </div>*/
/*                     <div class="btn-group" role="group">*/
/*                         <button type="button" id="following" class="btn btn-default" href="#tab3" data-toggle="tab"><span class="glyphicon glyphicon-comment" aria-hidden="true"></span>*/
/*                             <div class="hidden-xs">Komentarze</div>*/
/*                         </button>*/
/*                     </div>*/
/*                 </div>*/
/* */
/*                 <div class="well">*/
/*                     <div class="tab-content">*/
/*                         <div class="tab-pane fade in active" id="tab1">*/
/*                             <div class="col-sm-3 text-center">*/
/*                                 <div class="row"><a href="{{ path('fos_user_profile_edit') }}" class="text-center new-account"><span class="glyphicon glyphicon-wrench"></span> Edytuj dane osobowe</a></div>*/
/*                                 <div class="row"><a href="{{ path('fos_user_change_password') }}" class="text-center new-account"><span class="glyphicon glyphicon-wrench"></span> Zmień hasło</a></div>*/
/*                                 <div class="row"><a href="{{ path('App_MojeWystawioneOgloszenia') }}" class="text-center new-account"><span class="glyphicon glyphicon-list-alt"></span> Wystawione ogłoszenia</a></div>*/
/*                             </div>*/
/*                             <div class="col-sm-3" id="tab11">*/
/*                                 <h4>Informacje o mnie</h4>*/
/*                                 <p>Imie i nazwisko: {{ user.imie }} {{ user.nazwisko }}</p>*/
/*                                 <p>Nazwa użytkownika: {{ user.username }}</p>*/
/*                             </div>*/
/*                             <div >*/
/*                                 <h4>Dane kontaktowe</h4>*/
/*                                 <p>Adres email: {{ user.email }}</p>*/
/*                                 <p>Numer telefonu: {{ user.telefon }}</p>*/
/*                             </div>*/
/*                         </div>*/
/*                         <div class="tab-pane fade in" id="tab2">*/
/*                             <table class="table">*/
/*                                 <tr>*/
/*                                     <th>Tytuł</th>*/
/*                                     <th>Kategoria</th>*/
/*                                     <th>Cena</th>*/
/*                                 </tr>*/
/*                                 <tr>*/
/*                                         <td><a href="#"> tytul</a></td>*/
/*                                         <td>kategoria</td>*/
/*                                         <td>zł/miesiąc</td>*/
/*                                         <td>*/
/*                                             <a href="#"><span class="glyphicon glyphicon-trash"></span> Usuń</a>*/
/*                                         </td>*/
/*                                 </tr>*/
/*                             </table>*/
/*                         </div>*/
/*                         <div class="tab-pane fade in" id="tab3">*/
/*                             <ul class="media-list">*/
/*                                 <li class="media">*/
/*                                     <a class="pull-left" href="{{ path('_profil', {'id': 'x'}) }}">*/
/*                                         <img class="media-object img-circle" src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png" alt="profile">*/
/*                                     </a>*/
/*                                     <div class="media-body">*/
/*                                         <div class="well well-lg">*/
/*                                             <h4 class="media-heading text-uppercase reviews">Kajoj</h4>*/
/*                                             <p class="media-comment">*/
/*                                                 Ale zajebiste, co?*/
/*                                             </p>*/
/*                                         </div>*/
/*                                     </div>*/
/*                                 </li>*/
/*                             </ul>*/
/*                         </div>*/
/*                     </div>*/
/*                 </div>*/
/* */
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* {% endblock fos_user_content %}*/
/* */
