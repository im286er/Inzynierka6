<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/css')) {
            if (0 === strpos($pathinfo, '/css/95e3bdb')) {
                // _assetic_95e3bdb
                if ($pathinfo === '/css/95e3bdb.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '95e3bdb',  'pos' => NULL,  '_format' => 'css',  '_route' => '_assetic_95e3bdb',);
                }

                // _assetic_95e3bdb_0
                if ($pathinfo === '/css/95e3bdb_part_1_register2_1.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '95e3bdb',  'pos' => 0,  '_format' => 'css',  '_route' => '_assetic_95e3bdb_0',);
                }

            }

            if (0 === strpos($pathinfo, '/css/6794198')) {
                // _assetic_6794198
                if ($pathinfo === '/css/6794198.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 6794198,  'pos' => NULL,  '_format' => 'css',  '_route' => '_assetic_6794198',);
                }

                // _assetic_6794198_0
                if ($pathinfo === '/css/6794198_login_1.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 6794198,  'pos' => 0,  '_format' => 'css',  '_route' => '_assetic_6794198_0',);
                }

            }

            if (0 === strpos($pathinfo, '/css/0c961fa')) {
                // _assetic_0c961fa
                if ($pathinfo === '/css/0c961fa.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '0c961fa',  'pos' => NULL,  '_format' => 'css',  '_route' => '_assetic_0c961fa',);
                }

                // _assetic_0c961fa_0
                if ($pathinfo === '/css/0c961fa_part_1_style_1.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '0c961fa',  'pos' => 0,  '_format' => 'css',  '_route' => '_assetic_0c961fa_0',);
                }

            }

            if (0 === strpos($pathinfo, '/css/9b0345b')) {
                // _assetic_9b0345b
                if ($pathinfo === '/css/9b0345b.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '9b0345b',  'pos' => NULL,  '_format' => 'css',  '_route' => '_assetic_9b0345b',);
                }

                // _assetic_9b0345b_0
                if ($pathinfo === '/css/9b0345b_part_1_glowna_1.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '9b0345b',  'pos' => 0,  '_format' => 'css',  '_route' => '_assetic_9b0345b_0',);
                }

            }

            if (0 === strpos($pathinfo, '/css/e3aff0d')) {
                // _assetic_e3aff0d
                if ($pathinfo === '/css/e3aff0d.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'e3aff0d',  'pos' => NULL,  '_format' => 'css',  '_route' => '_assetic_e3aff0d',);
                }

                // _assetic_e3aff0d_0
                if ($pathinfo === '/css/e3aff0d_noweogloszenie_1.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'e3aff0d',  'pos' => 0,  '_format' => 'css',  '_route' => '_assetic_e3aff0d_0',);
                }

            }

            if (0 === strpos($pathinfo, '/css/4a15a66')) {
                // _assetic_4a15a66
                if ($pathinfo === '/css/4a15a66.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '4a15a66',  'pos' => NULL,  '_format' => 'css',  '_route' => '_assetic_4a15a66',);
                }

                // _assetic_4a15a66_0
                if ($pathinfo === '/css/4a15a66_profil_1.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '4a15a66',  'pos' => 0,  '_format' => 'css',  '_route' => '_assetic_4a15a66_0',);
                }

            }

            if (0 === strpos($pathinfo, '/css/b17d528')) {
                // _assetic_b17d528
                if ($pathinfo === '/css/b17d528.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'b17d528',  'pos' => NULL,  '_format' => 'css',  '_route' => '_assetic_b17d528',);
                }

                // _assetic_b17d528_0
                if ($pathinfo === '/css/b17d528_profiluzytkownika_1.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'b17d528',  'pos' => 0,  '_format' => 'css',  '_route' => '_assetic_b17d528_0',);
                }

            }

        }

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_purge
                if ($pathinfo === '/_profiler/purge') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:purgeAction',  '_route' => '_profiler_purge',);
                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            if (0 === strpos($pathinfo, '/_configurator')) {
                // _configurator_home
                if (rtrim($pathinfo, '/') === '/_configurator') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_configurator_home');
                    }

                    return array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::checkAction',  '_route' => '_configurator_home',);
                }

                // _configurator_step
                if (0 === strpos($pathinfo, '/_configurator/step') && preg_match('#^/_configurator/step/(?P<index>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_configurator_step')), array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::stepAction',));
                }

                // _configurator_final
                if ($pathinfo === '/_configurator/final') {
                    return array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::finalAction',  '_route' => '_configurator_final',);
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        // StronaGlowna
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'StronaGlowna');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\GlownaController::newAction',  '_route' => 'StronaGlowna',);
        }

        // NoweOgloszenie
        if ($pathinfo === '/NoweOgloszenie') {
            return array (  '_controller' => 'AppBundle\\Controller\\NoweOgloszenieController::newAction',  '_route' => 'NoweOgloszenie',);
        }

        if (0 === strpos($pathinfo, '/oferta')) {
            // App_Obserwuj
            if (preg_match('#^/oferta/(?P<idOferty>[^/]++)/obserwuj$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'App_Obserwuj')), array (  '_controller' => 'AppBundle\\Controller\\ObserwujController::obserwujAction',));
            }

            // Oferta
            if (preg_match('#^/oferta/(?P<idOferty>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'Oferta')), array (  '_controller' => 'AppBundle\\Controller\\OfertaController::showAction',));
            }

        }

        if (0 === strpos($pathinfo, '/profil')) {
            // OfertyUzytkownika
            if (preg_match('#^/profil/(?P<id>[^/]++)/oferty$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'OfertyUzytkownika')), array (  '_controller' => 'AppBundle\\Controller\\OfertyUzytkownikaController::listAction',));
            }

            // ProfilUzytkownika
            if (preg_match('#^/profil/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'ProfilUzytkownika')), array (  '_controller' => 'AppBundle\\Controller\\ProfilUzytkownikaController::showAction',));
            }

        }

        // App_UsunOferte
        if (0 === strpos($pathinfo, '/oferta') && preg_match('#^/oferta/(?P<idOferty>[^/]++)/delete$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'App_UsunOferte')), array (  '_controller' => 'AppBundle\\Controller\\UsunOferteController::deletebyAction',));
        }

        // App_MojeWystawioneOgloszenia
        if ($pathinfo === '/profile/oferty') {
            return array (  '_controller' => 'AppBundle\\Controller\\WystawioneOgloszeniaController::listAction',  '_route' => 'App_MojeWystawioneOgloszenia',);
        }

        if (0 === strpos($pathinfo, '/log')) {
            if (0 === strpos($pathinfo, '/login')) {
                // fos_user_security_login
                if ($pathinfo === '/login') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_fos_user_security_login;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::loginAction',  '_route' => 'fos_user_security_login',);
                }
                not_fos_user_security_login:

                // fos_user_security_check
                if ($pathinfo === '/login_check') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_fos_user_security_check;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::checkAction',  '_route' => 'fos_user_security_check',);
                }
                not_fos_user_security_check:

            }

            // fos_user_security_logout
            if ($pathinfo === '/logout') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_fos_user_security_logout;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::logoutAction',  '_route' => 'fos_user_security_logout',);
            }
            not_fos_user_security_logout:

        }

        if (0 === strpos($pathinfo, '/profile')) {
            // fos_user_profile_show
            if (rtrim($pathinfo, '/') === '/profile') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_fos_user_profile_show;
                }

                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'fos_user_profile_show');
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::showAction',  '_route' => 'fos_user_profile_show',);
            }
            not_fos_user_profile_show:

            // fos_user_profile_edit
            if ($pathinfo === '/profile/edit') {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_fos_user_profile_edit;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::editAction',  '_route' => 'fos_user_profile_edit',);
            }
            not_fos_user_profile_edit:

        }

        if (0 === strpos($pathinfo, '/re')) {
            if (0 === strpos($pathinfo, '/register')) {
                // fos_user_registration_register
                if (rtrim($pathinfo, '/') === '/register') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_fos_user_registration_register;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'fos_user_registration_register');
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::registerAction',  '_route' => 'fos_user_registration_register',);
                }
                not_fos_user_registration_register:

                if (0 === strpos($pathinfo, '/register/c')) {
                    // fos_user_registration_check_email
                    if ($pathinfo === '/register/check-email') {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_fos_user_registration_check_email;
                        }

                        return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::checkEmailAction',  '_route' => 'fos_user_registration_check_email',);
                    }
                    not_fos_user_registration_check_email:

                    if (0 === strpos($pathinfo, '/register/confirm')) {
                        // fos_user_registration_confirm
                        if (preg_match('#^/register/confirm/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                                $allow = array_merge($allow, array('GET', 'HEAD'));
                                goto not_fos_user_registration_confirm;
                            }

                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_registration_confirm')), array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmAction',));
                        }
                        not_fos_user_registration_confirm:

                        // fos_user_registration_confirmed
                        if ($pathinfo === '/register/confirmed') {
                            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                                $allow = array_merge($allow, array('GET', 'HEAD'));
                                goto not_fos_user_registration_confirmed;
                            }

                            return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmedAction',  '_route' => 'fos_user_registration_confirmed',);
                        }
                        not_fos_user_registration_confirmed:

                    }

                }

            }

            if (0 === strpos($pathinfo, '/resetting')) {
                // fos_user_resetting_request
                if ($pathinfo === '/resetting/request') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_fos_user_resetting_request;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::requestAction',  '_route' => 'fos_user_resetting_request',);
                }
                not_fos_user_resetting_request:

                // fos_user_resetting_send_email
                if ($pathinfo === '/resetting/send-email') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_fos_user_resetting_send_email;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::sendEmailAction',  '_route' => 'fos_user_resetting_send_email',);
                }
                not_fos_user_resetting_send_email:

                // fos_user_resetting_check_email
                if ($pathinfo === '/resetting/check-email') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_fos_user_resetting_check_email;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::checkEmailAction',  '_route' => 'fos_user_resetting_check_email',);
                }
                not_fos_user_resetting_check_email:

                // fos_user_resetting_reset
                if (0 === strpos($pathinfo, '/resetting/reset') && preg_match('#^/resetting/reset/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_fos_user_resetting_reset;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_resetting_reset')), array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::resetAction',));
                }
                not_fos_user_resetting_reset:

            }

        }

        // fos_user_change_password
        if ($pathinfo === '/profile/change-password') {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_fos_user_change_password;
            }

            return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ChangePasswordController::changePasswordAction',  '_route' => 'fos_user_change_password',);
        }
        not_fos_user_change_password:

        // _uploader_upload_gallery
        if ($pathinfo === '/_uploader/gallery/upload') {
            if ($this->context->getMethod() != 'POST') {
                $allow[] = 'POST';
                goto not__uploader_upload_gallery;
            }

            return array (  '_controller' => 'oneup_uploader.controller.gallery:upload',  '_format' => 'json',  '_route' => '_uploader_upload_gallery',);
        }
        not__uploader_upload_gallery:

        // _home
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', '_home');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\GlownaController::newAction',  '_route' => '_home',);
        }

        if (0 === strpos($pathinfo, '/oferta')) {
            // _oferta
            if (preg_match('#^/oferta/(?P<idOferty>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_oferta')), array (  '_controller' => 'AppBundle\\Controller\\OfertaController::showAction',));
            }

            // _usun
            if (preg_match('#^/oferta/(?P<idOferty>[^/]++)/delete$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_usun')), array (  '_controller' => 'AppBundle\\Controller\\UsunOferteController::deletebyAction',));
            }

            // _obserwuj
            if (preg_match('#^/oferta/(?P<idOferty>[^/]++)/obserwuj$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_obserwuj')), array (  '_controller' => 'AppBundle\\Controller\\ObserwujController::obserwujAction',));
            }

        }

        if (0 === strpos($pathinfo, '/profil')) {
            // _profil
            if (preg_match('#^/profil/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_profil')), array (  '_controller' => 'AppBundle\\Controller\\ProfilUzytkownikaController::showAction',));
            }

            // _ofertyuser
            if (preg_match('#^/profil/(?P<id>[^/]++)/oferty$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_ofertyuser')), array (  '_controller' => 'AppBundle\\Controller\\OfertyUzytkownikaController::showAction',));
            }

        }

        if (0 === strpos($pathinfo, '/admin')) {
            // easyadmin
            if (rtrim($pathinfo, '/') === '/admin') {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'easyadmin');
                }

                return array (  '_controller' => 'JavierEguiluz\\Bundle\\EasyAdminBundle\\Controller\\AdminController::indexAction',  '_route' => 'easyadmin',);
            }

            // admin
            if (rtrim($pathinfo, '/') === '/admin') {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'admin');
                }

                return array (  '_controller' => 'JavierEguiluz\\Bundle\\EasyAdminBundle\\Controller\\AdminController::indexAction',  '_route' => 'admin',);
            }

            // _easyadmin_render_css
            if ($pathinfo === '/admin/_css/admin.css') {
                return array (  '_controller' => 'JavierEguiluz\\Bundle\\EasyAdminBundle\\Controller\\AdminController::renderCssAction',  '_route' => '_easyadmin_render_css',);
            }

        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
